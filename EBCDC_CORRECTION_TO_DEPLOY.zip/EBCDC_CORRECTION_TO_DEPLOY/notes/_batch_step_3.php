<?php 
$noneButton = " "; 
$maker = $batch_lines->Creator_4;
?>
<?php 
if (isset($options['ALL']['bank-charges-attestation-printing'])): 
    $validation_date = $batch_lines->Validation_31 ?? null;
    $disableButtons = false;
    $disableAttestation = true; 

    if ($validation_date) 
    {
        $validationDateObj = new DateTime($validation_date);
        $now = new DateTime();

        # Comparer uniquement la date (Y-m-d)
        if ($now->format('Y-m-d') === $validationDateObj->format('Y-m-d')) 
        {
            # Si c'est le même jour, on désactive
            $disableButtons = true;
            # Actif si même jour
            $disableAttestation = false; 
        }
    }
endif;
?>
<?php $infos = json_decode($batch_lines->Notereference_34, true); ?>

<div id="message"></div>
<div id="loader"><?php echo ""; ?></div>

<div class="row">
    <div class="col-md-12">
        <?php if ($_SESSION['Logiref_role'] == 3 &&  isset($options['ALL']['client-exchange-rate-override']) && ($batch_lines->Tauxflag_28 ?? ' ')== "1"): ?> 
            <?php $noneButton = "d-none"; ?>
            <div id="loader2">
                <div class="alert alert-info text-black">
                    Une opération d’un montant supérieur à <b>5 000&nbsp;$</b> nécessite votre intervention.
                    Veuillez vérifier et confirmer le taux de change à appliquer 
                    <b>[<?= "CDF " . number_format($batch_lines->Taux_22, 2, '.', ' '); ?>]</b>
                    avant validation, puis cliquez sur le bouton <b>« Traiter »</b> afin de prendre ce taux en compte.
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($_SESSION['Logiref_role'] == 3 &&  isset($options['ALL']['client-exchange-rate-override']) && ($batch_lines->Tauxflag_28 ?? ' ')== "2"): ?> 
        <div id="loader2">
            <div class="alert alert-info text-black">
                Une opération d’un montant supérieur à <b>5 000&nbsp;$</b> nécessite votre attention.
                Le taux de change a été traité et confirmé. 
                Taux à appliquer : 
                <b>[<?= "CDF " . number_format($batch_lines->Taux_22, 2, '.', ' '); ?>]</b>. <br>
                Veuillez cliquer sur le bouton <b>« Valider »</b> afin de finaliser le traitement du paiement.
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($_SESSION['Logiref_role'] == 4 &&  isset($options['ALL']['client-exchange-rate-override']) && ($batch_lines->Tauxflag_28 ?? ' ') == "5"): ?> 
                <div id="loader2"><div class="alert alert-info text-black">Le taux publié <b>[<?= "CDF " . number_format($batch_lines->Taux_22, 2, '.', ' '); ?>]</b> pour cette opération n’est pas correct. Veuillez le modifier et confirmer le taux de change à appliquer avant validation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
        <?php endif; ?>
    </div>    
</div>

<?php echo form_open('', array('id' => 'main_form', 'class' => '')); ?> 
<style>.input-no-border {border-top: 0 !important; border-left: 0 !important; border-right: 0 !important; background:none !important; padding-left: 0 !important; }</style>
<?php $chtml->box_body_opening('', true); ?>
    <div class="col-md-12">
        <input type="hidden" name="Taux" value="<?= $batch_lines->Taux_22 ?? "" ?>" />
        <input type="hidden" name="RefOp" value="<?= $batch_lines->Refop_18 ?? ""; ?>" id="refOp" />
        <input type="hidden" name="Beneficaire" value="<?= $batch_lines->Beneficaire_7 ?? ""; ?>" />
        <input type="hidden" name="Commission" value="<?= $batch_lines->Commission_15 ?? 0; ?>" />
        <input type="hidden" name="Logirefid" value="" id="batch_id" />

        <div class="col-md-12 p-0">
            <div class="row">
                <div class="col-md-12 p-0">
                    <h2 class=" f20 w-300 page-header">Traitement des notes  en lot</h2>
                </div>
                <div class="col-md-7 bRight">
                    <div class="row">
                        <div class="col-md-12">
                            <br/><br/>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Service recouvrement</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?=  $services["DGRAD"][$batch_lines->Service_8] ?? ""; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Numéro impôt</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $batch_lines->Nif_11 ?? ""; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Désignation</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $batch_lines->Designation_12 ?? ""; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">intitulé du compte</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?=  $batch_lines->Intitule_21 ?? ""; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Compte du client</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b>  <?= $batch_lines->Compte_19; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Devise du Compte</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b>  <?= $batch_lines->Devise_20; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Mode de paiement</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $modes[$batch_lines->Mode_17] ?? "" ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Montant total du lot</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= number_format(($batch_lines->Montant_13 ?? 0),2,","," "). " ".$batch_lines->Devise_14; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Total Commission</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= number_format(($batch_lines->Commission_15 ?? 0),2,","," "). ' ' .$batch_lines->Devise_16 ; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Total TVA</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= number_format((($batch_lines->Commission_15 * 0.16) ?? 0),2,","," "). " " .$batch_lines->Devise_16; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Total à payer</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b>  <?= number_format(($batch_lines->Montanttotal_27 ?? 0),2,","," ")." ". $batch_lines->Devise_14; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black font-weight-bold">Total des paiements</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $batch_lines->Nombrepaiements_26 ; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <?php if (!empty($failds)) : ?>
                        <div class="card p-3">
                            <div class="card-header bg-gray text-white" style="cursor:pointer;" data-toggle="collapse" data-target="#notesCollapse">
                                <h4 class="mb-0">
                                    <i id="toggleIcon" class="fa fa-chevron-down"></i> &nbsp; Liste des notes
                                </h4>
                            </div>

                            <div id="notesCollapse" class="collapse show">
                                <div class="card-body p-0">
                                    <table id="notesTable" class="table table-striped table-hover mb-0">
                                        <thead class="bg-light">
                                            <tr>
                                                <th width="10">#</th>
                                                <th width="">Art. Budg.</th>
                                                <th>Référence</th>
                                                <th>Montant</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $i = 1; foreach ($failds as $row) : ?>
                                                <tr id="line<?= $i; ?>">
                                                    <td><?= $i; ?></td>
                                                    <td><?= $row->recette  ?></td>
                                                    <td><?= $row->reference  ?></td>
                                                    <td class="text-success font-bold"><?= number_format($row->amount, 2, ".", " "). ' '.$row->devise; ?></td>
                                                </tr>
                                            <?php $i++; endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div id="footpage" class="clearfix"></div>
                <div class="col-12 border-bottom">
                    <br><br>
                </div>
            </div>
        </div>

        <div class="box-body">
            <!------------------------- Repartitions  ------------------------------>
            <div class="row>">
                <div class="col-md-12"><br /><label>Sch&eacute;ma de comptabilisation </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
            </div>
            <div class="row"><div class="col-md-12" id="loader_scheme"></div></div>
            <div class="row">
                <div id="Comptabilisation" class="col-md-12"></div>
            </div>
            <!-------------------------  END  ------------------------------>

            <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
            <div class="row">
                <div class="col-md-12"><br/><label class="page-header">Partie additionnelle : Frais liés aux attestations</label><br /></div>
            </div>
            <div class="row">
                <div class="col-md-5">
                    <div class="form-check abc-checkbox abc-checkbox-success">
                        <input class="form-check-input" id="print_attestation" <?= ((isset($infos['paid_attestation']) && $_SESSION['Logiref_role'] != 4) || ($_SESSION['Logiref_role'] == 4 && $batch_lines->Status_2 == "2")) ? "disabled":""; ?> type="checkbox" <?= isset($infos['paid_attestation']) ? "checked" : "" ?>  name="Infos[paid_attestation]" value="<?= isset($infos['paid_attestation']) ? $infos['paid_attestation'] : "" ?>" >
                        <label class="form-check-label text-blue font-bold" for="print_attestation">
                            Frais liés à l’impression de l'attestations
                        </label>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="form-check abc-checkbox">
                        <input 
                            class="form-check-input" id="print_duplicata" type="checkbox" 
                            <?= ($disableButtons || $_SESSION['Logiref_role'] == 4 || $batch_lines->Printattestation_35 == 0) ? "disabled":"" ?>  
                            name="Infos[paid_duplicata]" 
                            value="<?= isset($infos['paid_duplicata']) ? $infos['paid_duplicata'] : "" ?>"
                        >
                        <label class="form-check-label text-blue font-bold" for="print_duplicata">
                            Frais de duplicata d’attestation
                        </label>
                    </div>
                </div>
            </div>
            <?php endif ?>

            <div class="row">
                <div class="col-md-12"><br><br></div>
            </div>

            <div  class="box-footer clearfix">
                <div class="row">
                    <div id="createPaiement" class="col-md-12">
                        <!-------------------------  Paiement en attente de validation  du taux ------------------------------>
                        <?php if ($_SESSION['Logiref_role'] == 3 && isset($options['ALL']['client-exchange-rate-override']) && ($batch_lines->Tauxflag_28 ?? ' ') == "1"): ?>
                            <button type="button" id="treat" <?= ($batch_lines->Tauxflag_28 == "0")? 'disabled':''; ?> class="btn btn-success pull-left"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <button type="button"  id="dismissal" class="btn btn-danger"><i class="fa fa-print"></i>&nbsp;&nbsp;~Rejet ce paiement&nbsp;</button>&nbsp;&nbsp;
                        <?php endif; ?>

                        <!-------------------------  Paiement en attente de validation  ------------------------------> 
                        <?php if($batch_lines->Status_2 ==1 && ($_SESSION['Logiref_role']!=4)): ?>
                            <?php if($_SESSION['Logiref_role']!=5):?>
                                <button type="submit" id="validate" class="btn btn-success pull-left <?= $noneButton;  ?>" ><i class="fa fa-print"></i>&nbsp;&nbsp;Valider&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <button type="button" id="delete" class="btn btn-danger <?= $noneButton;  ?>"><i class="fa fa-print"></i>&nbsp;&nbsp;Supprimer ce paiement&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <?php endif; ?>
                            <button type="button" id="print" disabled="" class="btn btn-primary <?= $noneButton;  ?>"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <button type="button" id="schema"  class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le sch&eacute;ma comptable &nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <?php endif; ?>

                        <?php if ($batch_lines->Status_2 ==2): ?>

                            <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                                <button type="button" id="paid_duplicata" class="btn btn-success d-none"><i class="fa fa-save"></i>&nbsp;&nbsp;Payer le duplicata&nbsp;&nbsp;</button>&nbsp;&nbsp;
                                <button type="button" id="treat_duplicata" class="btn btn-primary d-none"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                            <?php endif; ?>

                            <button type="button" id="schema" class="btn btn-primary">
                                <i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le schéma comptable&nbsp;&nbsp;
                            </button>&nbsp;&nbsp;

                            <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                                <?php if (((isset($infos['paid_attestation'])) && !$disableAttestation) || ($batch_lines->Printattestation_35 == 0)): ?>
                                    <button type="button" id="print" class="btn btn-primary">
                                        <i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;
                                    </button>&nbsp;&nbsp;
                                <?php else: ?>
                                    <button type="button" id="print" disabled class="btn btn-primary">
                                        <i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;
                                    </button>&nbsp;&nbsp;
                                <?php endif; ?>
                            <?php else : ?>
                                <button type="button" id="print" class="btn btn-primary">
                                    <i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;
                                </button>&nbsp;&nbsp;
                            <?php endif; ?>
                        <?php endif; ?>
                        <button type="button" id="cancel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $chtml->box_body_closing(); ?>

<?php echo form_close(); ?>


<script type="text/javascript"  charset="utf-8">

    $(document).ready(function () {
        $('#notesTable').DataTable({
            paging: true,
            pageLength: 5,
            lengthChange: false,
            searching: false,
            ordering: true,
            info: true,
            autoWidth: false
        });
    });

    $(document).ready(function(){
        // Quand le tableau est ouvert
        $('#notesCollapse').on('shown.bs.collapse', function () {
            $('#toggleIcon').removeClass('fa-chevron-up').addClass('fa-chevron-down');
        });
        // Quand le tableau est fermé
        $('#notesCollapse').on('hidden.bs.collapse', function () {
            $('#toggleIcon').removeClass('fa-chevron-down').addClass('fa-chevron-up');
        });
    });

    $("#print_duplicata").on("change", function () {
        const isChecked = $(this).is(':checked');

        if(isChecked){
            $("#treat_duplicata").removeClass("d-none");
        }else {
            $("#treat_duplicata").addClass("d-none");
        }
    });

    $("#pager").on("click", "#treat_duplicata", function(event){
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        scrollUP(); 

        $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxnotes/display/batch_instructions_duplicata'); ?>/<?php echo $batch_lines->Lot_24; ?>';
        var data = $("#main_form").serialize();

        $("#loader2").html("");

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                if(result.code =='E200'){
                        $('#message').html('');

                        $("#treat_duplicata").removeClass('d-none');
                        $("#treat_duplicata").prop("disabled", true);
                        $("#paid_duplicata").removeClass('d-none');

                        comptabilisation('<?php echo $batch_lines->Lot_24; ?>');

                        $('#message').html('<div class="alert alert-info text-black"> Le traitement a été effectué avec succès. Veuillez valider les frais afin de pouvoir imprimer l\'attestation.!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                } else if (result.code == "E405") {
                        $("#treat_duplicata").prop("disabled", true);
                        $("#paid_duplicata").removeClass('d-none');

                        $('#message').html('<div class="alert alert-info text-black"> L\'attestation ne peut pas être imprimée tant que des écritures restent en attente de validation. Merci de valider les frais concernés.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else {
                        $('#message').html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, veuillez refaire le traitement s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error: function(error) {
                $('#enregistrer').prop("disabled", false);
                $('#message').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    $("#pager").on("click", "#paid_duplicata", function(event){
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        scrollUP();
        $("#loader2").html("");

        $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxnotes/save/batch_attest_dup'); ?>/<?php echo $batch_lines->Id_0; ?>';
        var data = $("#main_form").serialize();

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                    if(result.code =='E407')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#loader').html("");
                        $('#paid_duplicata').prop("disabled", false);
                    }
                    else if(result.code =='E408')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Désolé, vous n\'êtes pas habilité à valider ce paiement suivant votre rôle, veuillez contacter votre administrateur s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#loader').html("");
                        $('#paid_duplicata').prop("disabled", false);
                    }
                    else if(result.code =='E409')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Paiement non validé, erreur des données invalides.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#loader').html("");
                        $('#paid_duplicata').prop("disabled", false);  
                    }
                    else if(result.code =='200')
                    {
                        $('#message').html(result.msg);

                        $('#paid_duplicata').prop("disabled", true);
                        $('#delete').prop("disabled",true); 

                        $('#print').prop("disabled",false); 
                        comptabilisation('<?php echo $batch_lines->Lot_24; ?>');
                    }
                    else 
                    {
                        $("#loader-sub-menu").html('');
						$('#message').html(result.msg);
                        $('#paid_duplicata').prop("disabled", false);
                    }
            },
            error: function(error) {
                $('#paid_duplicata').prop("disabled", false);
                $('#message').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    <?php if (isset($options['ALL']['client-exchange-rate-override'])): ?>
    $("#treat").click(function(event){
    
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        scrollUP(); 

        $('#loader2').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxnotes/save'); ?>/payment_validate_taux<?= $batch_lines->Id_0 > 0 ? '/'.$batch_lines->Id_0 : ''; ?>/batch';
        var data = $("#main_form").serialize();

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                if(result.code =='E200'){
                        $('#message').html('');
                        $("#loader2").html('');

                        $("#treat").addClass("d-none");
                        $("#dismissal").addClass("d-none");

                        $("#validate").removeClass("d-none");
                        $("#delete").removeClass("d-none");
                        $("#print").removeClass("d-none");
                        $('#loader').html(
                            '<div class="alert aSuccess text-white">' +
                                'Le taux a été traité et confirmé avec succès. ' +
                                'Veuillez valider ce paiement.' +
                                '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>' +
                            '</div>'
                        );
                } else if (result.code == "E405") {
                        $("#treat").prop("disabled", true);
                        $("#dismissal").prop("disabled", true);
                        $('#loader2').html('<div class="alert aDanger text-white"> Accès refusé : vous ne disposez pas des droits nécessaires pour valider le taux de change pour ce type de paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else {
                        $("#treat").prop("disabled", false);
                        $("#dismissal").prop("disabled", false);
                        $('#loader2').html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, Le taux est correct, mais la validation n’a pas pu être effectuée. Merci de réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error: function(error) {
                $('#treat').prop("disabled", false);
                $('#loader2').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    $("#dismissal").click(function(event){
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        scrollUP();

        var pid = '<?php echo $batch_lines->Id_0; ?>';

        swal({
                title: "REJET",
                text: "Etes-vous sûr de vouloir rejeter ce paiement ?",
                type: "warning",
                showCancelButton: true,
                cancelButtonText:"Non",
                confirmButtonText: "Oui",
                closeOnConfirm: true,
                confirmButtonColor: "#c9302c"
            },function(isConfirm){
                if(isConfirm) {
                    $('#loader2').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');

                    var url = '<?php echo base_url($module . '/taxnotes/save'); ?>/payment_dismissal_taux<?= $batch_lines->Id_0 > 0 ? '/'.$batch_lines->Id_0 : ''; ?>/batch';
                    scrollUP();
                    $.ajax({
                        type: 'GET',
                        url: url,
                        dataType: 'json',
                        encode: true,
                        success: function(result) {

                            if(result.code =='E200'){
                                    $('#loader2').html('');

                                    $("#treat").prop("disabled", true);
                                    $("#dismissal").prop("disabled", true);
                                    $('#loader2').html('<div class="alert aSuccess text-white">Rejet confirmé ! Le taux appliqué n’est pas valide et doit être mis à jour par l’opérateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                            } else if (result.code == "E405") {
                                    $("#treat").prop("disabled", true);
                                    $("#dismissal").prop("disabled", true);
                                    $('#loader2').html('<div class="alert aDanger text-white"> Accès refusé : vous ne disposez pas des droits nécessaires pour valider le taux de change pour ce type de paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else {
                                    $("#treat").prop("disabled", false);
                                    $("#dismissal").prop("disabled", false);
                                    $('#loader2').html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, Le taux est correct, mais la validation n’a pas pu être effectuée. Merci de réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                        },
                        error: function(error) {
                            $('#validate').prop("disabled", false);
                            $('#loader2').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                    });
                }
        });
    });
    <?php endif; ?>

    $('#main_form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        scrollUP();

        let data = $(this).serialize();
        let url = '<?php echo base_url($module . '/taxnotes/save/'); ?>/validate_batch<?php echo $batch_lines->Id_0 > 0 ? '/'.$batch_lines->Id_0 : ''; ?>';

        $('#validate').prop("disabled", true);

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(response) {

                if (response.code == 200) {
                    //$("#loader").html('<div class="alert aSuccess text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#loader").html(response.message);

                    $("#delete").prop("disabled", true);
                    $("#schema").prop("disabled", false);
                    $("#print").prop("disabled", false);

                    comptabilisation('<?= $batch_lines->Lot_24 ?? '' ?>');

                } else if (response.code == 407 || response.code == 409) {
                    $("#loader").html('<div class="alert aDanger text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else {
                    $('#loader').html(response.message);
                    //$("#loader").html('<div class="alert aDanger text-white">Une erreur inattendue est survenue<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error: function(xhr, status, error) {
                $("#loader").html('<div class="alert aDanger text-white">Erreur technique lors de l\'enregistrement. Veuillez réessayer plus tard<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    $("#print").click(function () {

        $("#validate").prop("disabled", true);

        let pid = '<?=  $batch_lines->Id_0 ?? '' ?>';
        let base = '<?php echo base_url($module . "/taximpression/display/attestation"); ?>';
        let param = 'batch'

        // Vérifier si param n'est pas null
        var url =  base + '/' + pid + '/' + param;

        // Ouvrir la fenêtre d’impression
        var w = window.open(url, "_blank");

        if (w) {
            // Vérifier que la fenêtre s'est bien ouverte
            $(w).on("load", function () {
                try {
                    // Lancer l'impression automatiquement
                    w.print();

                    $('#message').html('<div class="alert aSuccess text-white">Bravo! Attestation générée et impression lancée...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                } catch (e) {
                    // Si une erreur survient, on réactive le bouton
                    $("#print").prop("disabled", false);

                    $('#message').html('<div class="alert aDanger text-white"> Error : Erreur lors de la génération du PDF. Veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });

            // Gestion du cas où la fenêtre est fermée trop tôt
            var checkClosed = setInterval(function () {
                if (w.closed) {
                    clearInterval(checkClosed);
                    $("#print").prop("disabled", false);
                }
            }, 1000);

        } else {
            // Si le popup a été bloqué
            $("#print").prop("disabled", false);
            
            $('#message').html('<div class="alert aWarning text-white"> Information : Le navigateur a bloqué la génération de l’attestation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });

    $("#schema").click(function(){
                    
        let ref = '<?=  $batch_lines->Lot_24 ?? '' ?>';
        let url = '<?= base_url($module.'/taximpression/display/schema_batch'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        let w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
    });

    $("#cancel").click(function(){
        location.reload(true);
    });

    $("#delete").click(function () {

        let batchid = '<?php echo $batch_lines->Id_0; ?>';
        let logirefid = '<?php echo $batch_lines->Lot_24; ?>'

        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText: "Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        }, function (isConfirm) {
            if (isConfirm) {
                var url = '<?php echo base_url($module . '/taxnotes/save/delete_batch'); ?>/' + batchid + '/' + logirefid;

                $.ajax({
                    type: 'GET',
                    url: url,
                    dataType: 'json',
                    encode: true,
                    success: function (response) {
                        $('#loader').html('');

                        if (response.code == 200) {
                            $("#loader").html('<div class="alert aSuccess text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                            $("#enregistrer").prop("disabled", true);
                            $("#delete").prop("disabled", true);
                            $("#print").prop("disabled", false);

                        } else {
                            $("#loader").html('<div class="alert aDanger text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        } 
                    },
                    error: function (error) {
                        $('#loader').html('<div class="alert aDanger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                });
            }
        });
    });

    comptabilisation('<?= $batch_lines->Lot_24 ?? '' ?>');
    function comptabilisation(logirefid)
    {
        $('#loader_scheme').html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');

        var url = '<?php echo base_url($module.'/taxcomptabilisation/display/get_details_dgrad'); ?>/' + logirefid;
        $.get(url, function(data, status){
            $('#loader_scheme').html('');
            $("#Comptabilisation").html(data);
        });
    }

    function scrollUP() 
    {
        $('html, body').animate({
            scrollTop: $("#loader").offset()
        }, 20);
    }


</script>