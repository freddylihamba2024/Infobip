<?php 
$noneButton = " "; 
$maker = $batch_lines->Creator_4;

?>
<div id="message"></div>
<div id="loader"><?php echo ""; ?></div>

<div class="row">
    <div class="col-md-12">
        <?php if ($_SESSION['Logiref_role'] == 3 &&  isset($options['ALL']['client-exchange-rate-override']) && ($batch_lines->Tauxflag_28 ?? ' ')== "1"): ?> 
            <?php $noneButton = "d-none"; ?>
            <div id="loader2">
                <div class="alert alert-info text-black">
                    Une opération d’un montant supérieur à <b>5 000&nbsp;$</b> nécessite votre intervention.
                    Veuillez vérifier et confirmer le taux de change à appliquer 
                    <b>[<?= "CDF " . number_format($batch_lines->Taux_22, 2, '.', ' '); ?>]</b>
                    avant validation, puis cliquez sur le bouton <b>« Traiter »</b> afin de prendre ce taux en compte.
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($_SESSION['Logiref_role'] == 3 &&  isset($options['ALL']['client-exchange-rate-override']) && ($batch_lines->Tauxflag_28 ?? ' ')== "2"): ?> 
        <div id="loader2">
            <div class="alert alert-info text-black">
                Une opération d’un montant supérieur à <b>5 000&nbsp;$</b> nécessite votre attention.
                Le taux de change a été traité et confirmé. 
                Taux à appliquer : 
                <b>[<?= "CDF " . number_format($batch_lines->Taux_22, 2, '.', ' '); ?>]</b>. <br>
                Veuillez cliquer sur le bouton <b>« Valider »</b> afin de finaliser le traitement du paiement.
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($_SESSION['Logiref_role'] == 4 &&  isset($options['ALL']['client-exchange-rate-override']) && ($batch_lines->Tauxflag_28 ?? ' ') == "5"): ?> 
                <div id="loader2"><div class="alert alert-info text-black">Le taux publié <b>[<?= "CDF " . number_format($batch_lines->Taux_22, 2, '.', ' '); ?>]</b> pour cette opération n’est pas correct. Veuillez le modifier et confirmer le taux de change à appliquer avant validation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
        <?php endif; ?>
    </div>    
</div>

<?php echo form_open('', array('id' => 'main_form', 'class' => '')); ?> 
<style>.input-no-border {border-top: 0 !important; border-left: 0 !important; border-right: 0 !important; background:none !important; padding-left: 0 !important; }</style>
<?php $chtml->box_body_opening('', true); ?>
    <div class="col-md-12">
        <input type="hidden" name="Taux" value="<?= $batch_lines->Taux_22 ?? "" ?>" />
        <input type="hidden" name="RefOp" value="<?= $batch_lines->Refop_18 ?? ""; ?>" id="refOp" />
        <input type="hidden" name="Beneficaire" value="<?= $batch_lines->Beneficaire_7 ?? ""; ?>" />
        <input type="hidden" name="Commission" value="<?= $batch_lines->Commission_15 ?? 0; ?>" />
        <input type="hidden" name="Commission_lot" value="<?= $batch_lines->Commission_15 ?? 0; ?>" />
        <input type="hidden" name="Id_0" value="<?= $batch_lines->Id_0 ?? ""; ?>" />
        <input type="hidden" name="Logirefid" value="<?= $batch_lines->Lot_24 ?? ""; ?>" id="batch_id" />
        <input type="hidden" name="Notedate" value="<?= $batch_lines->Devise_14 ?? ""; ?>" id="" />

        <div class="col-md-12 p-0">
            <div class="row">
                <div class="col-md-12 p-0">
                    <h2 class=" f20 w-300 page-header">Traitement des notes  en lot</h2>
                    <br/>
                </div>
                <div class="col-12">
                    <div class="col-12">
                        <br><br>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Service recouvrement</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?=  $services["DGRAD"][$batch_lines->Service_8] ?? ""; ?>
                                                <input type="hidden" name="Service" value="<?=  $batch_lines->Service_8 ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Numéro impôt</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $batch_lines->Nif_11 ?? ""; ?>
                                                <input type="hidden" name="Nif" value="<?= $batch_lines->Nif_11 ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Désignation</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $batch_lines->Designation_12 ?? ""; ?>
                                                <input type="hidden" name="Designation" value="<?= $batch_lines->Designation_12 ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">intitulé du compte</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?=  $batch_lines->Intitule_21 ?? ""; ?>
                                                <input type="hidden" name="Account_name" value="<?=  $batch_lines->Intitule_21 ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Compte du client</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b>  <?= $batch_lines->Compte_19 ; ?>
                                                <input type="hidden" name="Compte" value="<?= $batch_lines->Compte_19  ?? ""; ?>" id="" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Devise du compte</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?=  $batch_lines->Devise_20  ?? ""; ?>
                                                <input type="hidden" name="Devise_compte" value="<?= $batch_lines->Devise_20  ?? ""; ?>" id="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Mode de paiement</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $modes[$batch_lines->Mode_17 ] ?? "" ?>
                                                <input type="hidden" name="Mode" value="<?= $batch_lines->Mode_17  ?? "" ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Montant total du lot</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <span id="total_lotHtml"><?= number_format(($batch_lines->Montant_13 ?? 0),2,","," ") ?> </span> <?=  $batch_lines->Devise_14 ; ?>
                                                <input type="hidden" name="Montant_note" value="<?= $batch_lines->Montant_13 ?? 0; ?>" id="total_lot" />
                                                <input type="hidden" name="Devise_note" value="<?= $batch_lines->Devise_14  ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Total Commission</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= number_format(($batch_lines->Commission_15  ?? 0),2,","," "). ' ' .$batch_lines->Devise_16 ; ?>
                                                <input type="hidden" name="Total_com" value="<?= $batch_lines->Commission_15  ?? 0; ?>" />
                                                <input type="hidden" name="Devise_com" value="<?= $batch_lines->Devise_16  ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Total TVA</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= number_format((($batch_lines->Commission_15 * 0.16) ?? 0),2,","," "). " " .$batch_lines->Devise_16; ?>
                                                <input type="hidden" name="Tva" value="<?= ($batch_lines->Commission_15 * 0.16) ?? 0 ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Total à payer</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <span id="total_to_paidHtml"><?= number_format(($batch_lines->Montanttotal_27 ?? 0),2,","," ") ?></span> <?= $batch_lines->Devise_14; ?>
                                                <input type="hidden" name="Total_topaid" value="<?= $batch_lines->Montanttotal_27 ?? 0; ?>" id="total_to_paid" />
                                                <input type="hidden" name="Devise_totalpaid" value="<?= $batch_lines->Devise_14 ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Nombre de notes</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $batch_lines->Nombrepaiements_26  ; ?>
                                                <input type="hidden" name="Total_line" value="<?= $batch_lines->Nombrepaiements_26  ?? 0; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="footpage" class="clearfix"></div>
                <div class="col-12 border-bottom">
                    <br><br>
                </div>
            </div>
        </div>

        <div class="p-0 border-top">
            <div class="box-body" id="box_body">
                       
                <?php  if (!empty($failds)) : ?>
                    <table id="notesTable" class="table table-striped table-hover">
                        <thead class="bg-gray">
                            <tr>
                                <th width="10px">#</th>
                                <th width="500px">Nature</th>
                                <th width="150px">Référence</th>
                                <th width="80px">Devise</th>
                                <th width="150">Montant</th>
                                <th class="text-center">Retour Logirad</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; foreach ($failds as $row): ?>
                                <tr id="line<?= $i; ?>">
                                    <td><span class="text-gray"><b><?= $i; ?></b></span></td>
                                    <td>
                                        <?php echo form_dropdown('recettes['.$i.']', $recettes, $row->recette, 'class="form-control input-no-border" '); ?>
                                    </td>
                                    <td>
                                        <input id="reference<?= $i; ?>" type="text" 
                                            value="<?= htmlspecialchars($row->reference); ?>" 
                                            name="references[<?= $i; ?>]" 
                                            class="form-control input-no-border" />
                                    </td>
                                    <td>
                                        <input id="devise<?= $i; ?>" type="text" 
                                            value="<?= htmlspecialchars($row->devise); ?>"  
                                            name="devises[<?= $i; ?>]"   
                                            class="form-control  input-no-border" readonly />
                                    </td>
                                    <td>
                                        <input id="amount<?= $i; ?>" type="text" 
                                            value="<?= number_format($row->amount, 2, ",", " "); ?>" 
                                            name="amounts[<?= $i; ?>]" 
                                            class="form-control input-no-border" />
                                    </td>
                                    <td class="text-center">
                                        <span id="logirad_result<?= $i; ?>" class="badge badge-danger">
                                            La vérification est momentanément impossible.
                                        </span>
                                    </td>
                                </tr>
                            <?php $i++; endforeach; ?>
                        </tbody>
                    </table>

                    <!-- conteneur caché pour inputs clonés --> 
                    <div id="hiddenInputs" style="display:none;"></div>
                <?php else : ?>
                    <section>
                        <div class="row fontawesome-icon-list f14 text-center" style="min-height: 50vh; padding-top: 20%;">
                            <i class="fa fa-fw fa-warning text-gray mystyle4 fa-3x"></i><br />
                            <h4 class="text-center mt-3">
                                <b>Aucune note disponible pour le moment.</b>
                            </h4>
                            <p class="text-muted">Veuillez vérifier vos données ou importer un fichier contenant des notes valides.</p>
                        </div>
                    </section>
                <?php endif; ?>
            </div>

            <div id="box_schema" class="d-none">
                <!------------------------- Repartitions  ------------------------------>
                <div class="row>">
                    <div class="col-md-12"><br /><label>Sch&eacute;ma de comptabilisation </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
                </div>
                <div class="row"><div class="col-md-12" id="loader_scheme"></div></div>
                <div class="row">
                    <div id="Comptabilisation" class="col-md-12"></div>
                </div>
                <!-------------------------  END  ------------------------------>
            </div>

            <div  class="box-footer clearfix">
                <div class="row">
                    <div id="createPaiement" class="col-md-12">
                        <button type="submit" id='save' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Modifier&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="print" disabled="disabled" class="btn btn-primary d-none"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="schema"  class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le sch&eacute;ma comptable &nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="delete" class="btn btn-danger"><i class="fa fa-print"></i>&nbsp;&nbsp;Supprimer ce paiement&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="cancel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $chtml->box_body_closing(); ?>

<?php echo form_close(); ?>


<script type="text/javascript"  charset="utf-8">

    $(document).ready(function () {
        $('#notesTable').DataTable({
            paging: true,
            pageLength: 5,
            lengthChange: false,
            searching: false,
            ordering: true,
            info: true,
            autoWidth: false
        });
    });

    $(document).ready(function() {
        var commission = parseFloat("<?= $batch_lines->Commission_15; ?>");
        var referenceDevise = "<?= $batch_lines->Devise_14; ?>";

        // Initialisation DataTable (si pas déjà fait)
        var table = $('#notesTable').DataTable();

        function recalcul_totals() {
            var total_lot = 0;

            // Récupérer toutes les cellules/inputs de la colonne "Montant"
            table.$("input[name^='amounts']").each(function() {
                var val = $(this).val().replace(/\s/g, '').replace(',', '.');
                var num = parseFloat(val);
                if (!isNaN(num)) {
                    total_lot += num;
                }
            });

            var tva = commission * 0.16;
            var total_to_paid = commission + tva + total_lot;

            if (referenceDevise === "CDF") {
                total_to_paid += (total_lot * 0.5) / 1000;
            }

            $("#total_lot").val(total_lot)
            $("#total_to_paid").val(total_to_paid)

            $("#total_lotHtml").text(total_lot.toLocaleString('fr-FR', {minimumFractionDigits:2}));
            $("#total_to_paidHtml").text(total_to_paid.toLocaleString('fr-FR', {minimumFractionDigits:2}));
        }

        // Déclenchement au changement des montants (sur toutes les pages)
        $('#notesTable').on('change', "input[name^='amounts']", function() {
            recalcul_totals();
        });

        // Premier calcul
        recalcul_totals();
    });



    $('#main_form').submit(function(event) {
        event.preventDefault();

        $("#loader").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        scrollUP();

        let table = $('#notesTable').DataTable();

        // Vider le conteneur caché avant chaque submit 
        $('#hiddenInputs').empty();

        // Cloner les inputs des pages non visibles
        table.$('input, select, textarea').each(function() {
            if (!$.contains(document, this)) {
                $(this).clone().appendTo('#hiddenInputs');
            }
        });

        let data = $(this).serialize();
        let url = '<?php echo base_url($module . '/taxnotes/save/'); ?>/update_batch<?php echo $batch_lines->Id_0 > 0 ? '/'.$batch_lines->Id_0 : ''; ?>';

        $('#save').prop("disabled", true);

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(response) {
                if (response.code == 200) {
                    $("#loader").html('<div class="alert aSuccess text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#step-2").removeClass('bg-green-active').addClass('bg-gray');
                    $("#step-3").removeClass('bg-gray').addClass('bg-green-active');
                    $("#schema").prop("disabled", false);

                    $("#batch_id").val(response.id);

                    $("#box_body").addClass('d-none');
                    $("#box_schema").removeClass('d-none');

                    comptabilisation(response.id);

                } else if (response.code == 401) {
                    $("#loader").html('<div class="alert aDanger text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#save').prop("disabled", false);
                } else if (response.code == 402 || response.code == 403 || response.code == 405) {
                    $("#loader").html('<div class="alert aDanger text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (response.code == 500) {
                    $("#loader").html('<div class="alert alert-info text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else {
                    $("#loader").html('<div class="alert aDanger text-white">Une erreur inattendue est survenue<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error: function(xhr, status, error) {
                $("#loader").html('<div class="alert aDanger text-white">Erreur technique lors de l\'enregistrement. Veuillez réessayer plus tard<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    $("#schema").click(function(){
                    
        let ref = '<?= $batch_lines->Lot_24 ?>';
        let url = '<?php echo base_url($module.'/taximpression/display/schema_batch'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        let w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
    });

    $("#cancel").click(function(){
        location.reload(true);
    });

    $("#delete").click(function () {

        let batchid = '<?php echo $batch_lines->Id_0; ?>';
        let logirefid = '<?php echo $batch_lines->Lot_24; ?>'

        swal({
            title: "SUPPRESSION",
            text: "Etes-vous sûr de vouloir supprimer ce paiement ?",
            type: "warning",
            showCancelButton: true,
            cancelButtonText: "Non",
            confirmButtonText: "Oui",
            closeOnConfirm: true,
            confirmButtonColor: "#c9302c"
        }, function (isConfirm) {
            if (isConfirm) {
                var url = '<?php echo base_url($module . '/taxnotes/save/delete_batch'); ?>/' + batchid + '/' + logirefid;

                $.ajax({
                    type: 'GET',
                    url: url,
                    dataType: 'json',
                    encode: true,
                    success: function (response) {
                        $('#loader').html('');

                        if (response.code == 200) {
                            $("#loader").html('<div class="alert aSuccess text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                            $("#enregistrer").prop("disabled", true);
                            $("#delete").prop("disabled", true);
                            $("#print").prop("disabled", false);

                        } else {
                            $("#loader").html('<div class="alert aDanger text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        } 
                    },
                    error: function (error) {
                        $('#loader').html('<div class="alert aDanger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                });
            }
        });
    });

    comptabilisation('<?= $batch_lines->Lot_24 ?? '' ?>');
    function comptabilisation(logirefid)
    {
        $('#loader_scheme').html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');

        var url = '<?php echo base_url($module.'/taxcomptabilisation/display/get_details_dgrad'); ?>/' + logirefid;
        $.get(url, function(data, status){
            $('#loader_scheme').html('');
            $("#Comptabilisation").html(data);
        });
    }

    function scrollUP() 
    {
        $('html, body').animate({
            scrollTop: $("#loader").offset()
        }, 20);
    }


</script>