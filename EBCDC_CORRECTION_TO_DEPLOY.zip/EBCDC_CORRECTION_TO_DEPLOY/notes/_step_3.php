<?php $maker = $encaissement->Makerid_9;
$feuille = '';
$infos = json_decode($encaissement->Notereference_30, true);
$disabled = "disabled";

?>
<?php if ($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11, 2, ",", " "); ?>
<?php if ($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28, 2, ",", " "); ?>
<?php if ($encaissement->Commission_23 > 0) $encaissement->Commission_23 = number_format($encaissement->Commission_23, 2, ",", " "); ?>
<?php if ($_SESSION['Logiref_role'] == 4 && $maker == $userid && $encaissement->Status_2 == 1 && $encaissement->Checkerid_10 == 0) $feuille = ''; ?>

<?php
if (isset($_POST['Reference_14']) && $_POST['Reference_14'] != '') {
    $reference = $_POST['Reference_14'];
} elseif (isset($content['Reference_32']) && $content['Reference_32'] != "") {
    $reference = $content['Reference_32'];
} else {
    $reference = "";
}
?>
<?php if (isset($_POST['Nif_17']) && $_POST['Nif_17'] != '') {
    $nif = $_POST['Nif_17'];
} elseif (isset($content['Nif']) && $content['Nif'] != "") {
    $nif = $content['Nif'];
} else {
    $nif = "";
} ?>
<?php
if (isset($client->Designation_5) && $client->Designation_5 != '') {
    $designation = $client->Designation_5;
} elseif (isset($content['Denomination']) && $content['Denomination'] != "") {
    $designation = $content['Denomination'];
} else {
    $designation = "";
}
?>
<?php
if (isset($_SESSION['Bank_rates'])) :
    $taux = json_decode($_SESSION['Bank_rates'], true);
else :
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;
if (!isset($infos['totalMontant'])) {
    $infos['totalMontant'] = '';
    $infos['totalDevise'] = $encaissement->Devise_12;
}
$customer_number = substr($encaissement->Compte_33, 5, 6); 
?>
<?php 
if (isset($options['ALL']['bank-charges-attestation-printing'])): 
    $validation_date = $encaissement->Validation_36 ?? null;
    $disableButtons = false;
    $disableAttestation = true; 

    if ($validation_date) 
    {
        $validationDateObj = new DateTime($validation_date);
        $now = new DateTime();

        # Comparer uniquement la date (Y-m-d)
        if ($now->format('Y-m-d') === $validationDateObj->format('Y-m-d')) 
        {
            # Si c'est le même jour, on désactive
            $disableButtons = true;
            # Actif si même jour
            $disableAttestation = false; 
        }
    }
endif;

$noneButton = " ";
?>

<?php echo form_open('', array('id' => 'form', 'class' => $view)); ?>
<style>label {min-width: 150px !important; }</style>

<div class="row">
    <div class="col-md-12">
        <?php if ($_SESSION['Logiref_role'] == 3 &&  isset($options['ALL']['client-exchange-rate-override']) && ($encaissement->Tauxflag_58 ?? ' ')== "1"): ?> 
            <?php $noneButton = "d-none"; ?>
            <div id="loader2">
                <div class="alert alert-info text-black">
                    Une opération d’un montant supérieur à <b>5 000&nbsp;$</b> nécessite votre intervention.
                    Veuillez vérifier et confirmer le taux de change à appliquer 
                    <b>[<?= "CDF " . number_format($encaissement->Taux_41, 2, '.', ' '); ?>]</b>
                    avant validation, puis cliquez sur le bouton <b>« Traiter »</b> afin de prendre ce taux en compte.
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($_SESSION['Logiref_role'] == 3 &&  isset($options['ALL']['client-exchange-rate-override']) && ($encaissement->Tauxflag_58 ?? ' ')== "2"): ?> 
        <div id="loader2">
            <div class="alert alert-info text-black">
                Une opération d’un montant supérieur à <b>5 000&nbsp;$</b> nécessite votre attention.
                Le taux de change a été traité et confirmé. 
                Taux à appliquer : 
                <b>[<?= "CDF " . number_format($encaissement->Taux_41, 2, '.', ' '); ?>]</b>. <br>
                Veuillez cliquer sur le bouton <b>« Valider »</b> afin de finaliser le traitement du paiement.
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            </div>
        </div>
        <?php endif; ?>

        <?php if ($_SESSION['Logiref_role'] == 4 &&  isset($options['ALL']['client-exchange-rate-override']) && ($encaissement->Tauxflag_58 ?? ' ') == "5"): ?> 
                <div id="loader2"><div class="alert alert-info text-black">Le taux publié <b>[<?= "CDF " . number_format($encaissement->Taux_41, 2, '.', ' '); ?>]</b> pour cette opération n’est pas correct. Veuillez le modifier et confirmer le taux de change à appliquer avant validation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div></div>
        <?php endif; ?>
    </div>    
</div> 

<div class="row">
	<div class="col-md-12" id="message"></div>
</div>
<?php $chtml->box_body_opening('', true); ?>
<input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
<input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
<input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
<input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
<input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
<input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
<input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
<input type="hidden" name="Notereference_30" value="<?php echo $encaissement->Notereference_30; ?>" />
<input type="hidden" id="compte_mad" value="<?php echo isset($compte_mad['account']) ? $compte_mad['account'] : ""; ?>" />
<input type="hidden" id="compte_mad_currency" value="<?php echo isset($compte_mad['currency']) ? $compte_mad['currency'] : ""; ?>" />
<input type="hidden" name="Infos[Branch_code]" value="<?= isset($infos['Branch_code']) ? $infos['Branch_code'] : ""; ?>"  id="branch_code" />

<?php $chtml->box_body_opening('', true); ?>

<div class="box-body">
    <div class="row">
        <div class="col-md-12">
            <h2 class=" f20  w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
        </div>
    </div>
    <!------------------------- Beneficiare  ------------------------------>
    <div class="row">
        <div class="col-md-12"><br/><label>Partie 1 : R&eacute;gies financi&egrave;re</label><br/></div>
    </div>
    <div class="row">
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label> 
                </span>
                <?php echo form_dropdown('Beneficaire_15', array('DGARD'), 'DGARD', ' class="form-control bg-gray" required="required"  '); ?>
                <?php if($encaissement->Id_0 !=NULL): ?>
                    <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                <?php endif; ?>
            </div>
        </div> 
        <div class="col-md-7">
            <div class="input-group" id="regie0">
                <span class="input-group-addon">
                    <label for="Service_16"><div id="ServiceId">Service recouvrement</div></label> 
                </span>
                <?php echo form_dropdown('Service_16', $services, $encaissement->Service_16, 'class="form-control select2" id="service" required="required" '); ?></span>
                <?php if ($encaissement->Id_0 != NULL) : ?>
                    <input type="hidden" name="" value="<?php echo $encaissement->Service_16; ?>" />
                <?php endif; ?>
            </div>
        </div> 
    </div> 

    <br>   
    <!-------------------------  Titre de perception  ------------------------------>
    <div class="row">    
        <div class="col-md-12"><br/><label>Partie 2 : Titre de paiement</label><br /></div>
    </div>
    <div class="row">
        <div class="col-md-5 ">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Noteid_26"><div id="TitreId">Num&eacute;ro</div></label> 
                </span>
                <?php echo form_input('Noteid_26', set_value('Noteid_26', $encaissement->Noteid_26), ' class="form-control form-control-lg" id="reftitre" maxlength="25"'); ?>
            </div>
        </div>
        <div class="col-md-7 ">
           <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notetype_25">Document</label> 
                </span>
                <?php echo form_dropdown('Notetype_25', $documents, $encaissement->Notetype_25, 'class="custom-select " disabled="disabled" id="doc" required="required" '); ?>
                <input type="hidden" name="Notetype_25" value="1">
            </div>
        </div>
    </div>

    <div class="row">
        <div id="bl" class="col-md-12"></div>
    </div>
    <div class="row">
        <div class="col-md-5 ">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notedate_27">Date &eacute;mission</label>
                </span>
                <?php echo form_input('Notedate_27', set_value('Notedate_27', date('d-m-Y', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            </div>
        </div>
        <div class="col-md-7 ">
            <div class="input-group"  id="recette0">
                <span class="input-group-addon">
                    <label for="Typerecette_17">Nature paiement</label> 
                </span>
                <?php echo form_dropdown('Typerecette_17', $recettes, $encaissement->Typerecette_17, 'class="form-control select2" id="recette" required="required" '); ?>
            </div>
        </div>
    </div>
    <!-- <div class="row">
        <div class="col-md-5 ">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Infos[NumeroTitre]">Num&eacute;ro de titre</label> 
                </span>
                <php echo form_input("Infos[NumeroTitre]", set_value("Infos[NumeroTitre]", (isset($infos['NumeroTitre'])) ? $infos['NumeroTitre'] : ''), ' class="form-control" id=""  maxlength="45"'); ?>
            </div>
        </div>
        <div class="col-md-7 ">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Infos[Motif]">Motif de paiement</label> 
                </span>
                <php echo form_input("Infos[Motif]", set_value("Infos[Motif]", (isset($infos['Motif'])) ? $infos['Motif'] : ''), ' id="" class="form-control" maxlength="45"  '); ?>
            </div>
        </div>
    </div> -->
    <div class="row">
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="standard">Ech&eacute;ance</label> 
                </span>
                <?php echo form_input("Infos[standard]", set_value("Infos[standard]", isset($infos['standard']) ? $infos['standard'] : ""), ' class="form-control form-control-lg" id="datepicker3" maxlength="25"'); ?>
            </div>
        </div>
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Notemontant_28">Montant de la note</label> 
                </span>
                <?php echo form_input('Notemontant_28', set_value('total', $encaissement->Notemontant_28), ' id="montantNote" class="form-control form-control-lg" required="required"'); ?>
            </div>
        </div>
        <div class="col-md-2">
            <div class="input-group">
                <span class="input-group-addon no-padding"></span>
                <?php echo form_dropdown('Notedevise_29', $devises, $encaissement->Notedevise_29, 'class="form-control" id="deviseNote"  required="required"'); ?>
            </div>
        </div>
    </div>
    <!------------------------- Payement  ------------------------------>
    <div class="row">
        <div class="col-md-5"><br /><span>Partie 3 : Client, Assujetti ou Contribuable. </span></div>
        <!-- <div class="col-md-7" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br /><label id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span style="color : green !important" id="accountname"><?php echo (isset($infos['accountname'])) ? $infos['accountname'] : ''; ?></span></label></div> -->
        <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
            <div class="col-md-5" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br /><label id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span style="color : green !important" id="accountname"><?php echo (isset($infos['accountname'])) ? $infos['accountname'] : ''; ?></span></label></div>
            <div class="col-md-2" id=""><span id="" class="text-red" style="padding-left:0px; "></span><br /><span id="" style=""><span  id="labelNumber"></span></span></div>
        <?php else: ?>
            <div class="col-md-7" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br /><label id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span style="color : green !important" id="accountname"><?php echo (isset($infos['accountname'])) ? $infos['accountname'] : ''; ?></span></label></div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Nif_13">Num&edot;ro imp&ocirc;t</label> 
                </span>
                <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control"  maxlength="86"'); ?>
            </div>
        </div> 
        <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
            <div class="col-md-5 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Designation_14" class="f12">D&eacute;signation</label> 
                    </span>
                    <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86"  '); ?>
                </div>
            </div>
            <div class="col-md-2 small-box">
                <div class="input-group">
                    <span class="input-group-addon no-padding"></span>
                    <?php echo form_input('Infos[CustomerNumber]', set_value('Infos[CustomerNumber]', isset($infos['CustomerNumber']) ? $infos['CustomerNumber'] : ""), 'class="form-control" id="customerNumber" maxlength="7" placeholder="Numéro du client" '); ?>
                </div>
            </div>
        <?php else: ?>
            <div class="col-md-7 small-box">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Designation_14" class="f12">D&eacute;signation</label> 
                    </span>
                    <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86" '); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <div class="row">
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Mode_19">Mode de paiement</label> 
                </span>
                <?php echo form_dropdown('Mode_19', $modes, $encaissement->Mode_19, 'class="form-control" required="required" id="modeId"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Taux_41">Taux de change</label> 
                </span>
                <?php echo form_input('Taux_41', ($encaissement->Taux_41 != "") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                   <label for="Datevaleur_31">Date paiement</label>
                </span>
                <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('d-m-Y', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Reference_32">R&eacute;f&eacute;rence de l&apos;OP</label>
                </span>
                <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control"'); ?>
            </div>
        </div> 
        <div class="col-md-5">
            <div class="input-group"> 
                <span class="input-group-addon">
                    <label for="Compte_33"><div id="compteLabel">Compte du client</div></label> 
                </span>
                <?php echo form_input('Compte_33', set_value('Compte_33', $encaissement->Compte_33), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                <input type="hidden" name="Infos[accountname]" value="<?php echo (isset($infos['accountname'])) ? $infos['accountname'] : ''; ?>" id="account_name">
                <input type="hidden" name="Infos[accountType]" value="<?php echo(isset($infos['accountType']))? $infos['accountType']:''; ?>" id="account_type">
                <input type="hidden" name="account_currency" disabled="disabled" value="" id="account_currency">
                <input type="hidden" name="account_balance" disabled="disabled" value="" id="account_balance">
            </div>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Montant_11">Montant &agrave; payer</label> 
                </span>
                <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required"'); ?>
            </div>
            <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Commission_23" class="f12">
                            <div id="commissionLabel">Commission</div>
                        </label>
                    </span>
                    <!-- Premier input collé au label -->
                    <?php echo form_input('Commission_23', set_value('Commission_23', isset($encaissement->Commission_23) ? $encaissement->Commission_23 : '0'),'class="form-control" id="commission" required="required"  placeholder="Com. Note"'); ?>

                    <!-- Deuxième input avec un petit espace -->
                    <span class="input-group-addon" style="background:transparent; border:none; padding:0 4px;"></span>
                    <?php if ($encaissement->Printattestation_57 == 0 && isset($infos['PaidATTESTATION'])): ?>
                        <?php echo form_input('Infos[CommissionAttestation]', set_value('Infos[CommissionAttestation]', isset($infos['CommissionAttestation']) ? $infos['CommissionAttestation'] : "0"),'class="form-control" id="commissionAttestation"  placeholder="Com. Attest." style="max-width:150px;"'); ?>
                    <?php else : ?>
                        <?php echo form_input('Infos[CommissionDuplicata]', set_value('Infos[CommissionDuplicata]', isset($infos['CommissionDuplicata']) ? $infos['CommissionDuplicata'] : "0"),'class="form-control" id="commissionAttestation"   placeholder="Com. Attest." style="max-width:150px;"'); ?>
                        <input type="hidden" name="Infos[CommissionAttestation]" value="<?= isset($infos['CommissionAttestation']) ? $infos['CommissionAttestation'] : "" ?>" >
                    <?php endif; ?>
                    <?php //echo form_input('Infos[CommissionAttestation]', set_value('Infos[CommissionAttestation]', isset($infos['CommissionAttestation']) ? $infos['CommissionAttestation'] : ""),'class="form-control" id="commissionAttestation" required="required"  placeholder="Com. Attest." style="max-width:150px;"'); ?>
                </div>
            <?php else : ?>
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Commission_23" class="f12"><div id="commissionLabel">Commission</div></label>
                    </span>
                    <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), 'class="form-control" id="commission" '); ?>
                </div>
            <?php endif; ?>
            <div class="input-group">
                <span class="input-group-addon">
                    <label for="Total">Montant total</label> 
                </span>
                <?php echo form_input("Infos[totalMontant]", set_value('Total', $infos['totalMontant']), 'class="form-control bg-gray" id="montantTotal"'); ?>
            </div>
        </div>
        <div class="col-md-2">
            <div class="input-group">
                <span class="input-group-addon no-padding"></span>
                <?php echo form_dropdown('Devise_34', $devises, $encaissement->Devise_34, 'class="form-control"  required="required" id="compteDevise"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon no-padding"></span>
                <?php echo form_dropdown('Devise_12', $devises, $encaissement->Devise_12, 'class="form-control"  required="required" id="recetteDevise"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon no-padding"></span>
                <?php echo form_dropdown('Devise_24', $devises, $encaissement->Devise_24, 'class="form-control"  required="required" id="commissionDevise"'); ?>
            </div>
            <div class="input-group">
                <span class="input-group-addon no-padding"></span>
                <?php echo form_dropdown("Infos[totalDevise]", $devises, $infos['totalDevise'], 'class="form-control bg-gray"  required="required" id="totalDevise"'); ?>
            </div>
        </div>
    </div>

    <!-------------------------  DGI Cotisation  ------------------------------>
    <div id="DGICotisation" style="<?php echo ($encaissement->Typerecette_17 == "IPRIER"  || $encaissement->Typerecette_17 == "IRPPDR11") ? '' : 'display: none;'; ?>">
        <div class="row"><div class="col-md-12"><br/><b>Payer uniquement la part de la DGI</b>&nbsp;<input type="checkbox" id="dgi_unique" <?php echo (isset($infos['QuotasINPP'], $infos['QuotasINSS'], $infos['QuotasONEM'], $infos['QuotasDGI'])) ? '' : 'checked'; ?>><br/><br/></div></div>
        <div class="row" id="dgi_cotisation_unique" style="<?php echo (isset($infos['QuotasINPP'], $infos['QuotasINSS'], $infos['QuotasONEM'], $infos['QuotasDGI'])) ? 'display: none;' : ''; ?>">
            <div class="col-md-6 small-box">
                <div class="form-group">
                    <label for="QuotasDGI">Quota DGI</label> 
                    <?php echo form_input("Infos[QuotasDGI]", set_value("Infos[QuotasDGI]", isset($infos['QuotasDGI']) ? $infos['QuotasDGI'] : ""), 'class="form-control" id="quota_dgi_unique" '); ?>
                </div>
            </div>
            <div class="col-md-6 small-box">
                <div class="form-group">
                    <label for="RefDGI">R&eacute;f&eacute;rence DGI</label> 
                    <?php echo form_input("Infos[RefDGI]", set_value("Infos[RefDGI]", ''), 'class="form-control"'); ?>
                </div>
            </div>
        </div>
        <div id="dgi_cotisation_avec_institution" style="<?php echo (isset($infos['QuotasINPP'], $infos['QuotasINSS'], $infos['QuotasONEM'], $infos['QuotasDGI'])) ? '' : 'display: none;'; ?>">
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="RefDGI">R&eacute;f&eacute;rence DGI</label> 
                        <?php echo form_input("Infos[RefDGI]", set_value("Infos[RefDGI]", isset($infos['RefDGI']) ? $infos['RefDGI'] : ""), 'class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="RefONEM">R&eacute;f&eacute;rence ONEM</label> 
                        <?php echo form_input("Infos[RefONEM]", set_value("Infos[RefONEM]", isset($infos['RefONEM']) ? $infos['RefONEM'] : ""), 'class="form-control" '); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="RefINPP">R&eacute;f&eacute;rence INPP</label> 
                        <?php echo form_input("Infos[RefINPP]", set_value("Infos[RefINPP]", isset($infos['RefINPP']) ? $infos['RefINPP'] : ""), 'class="form-control" '); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="RefINSS">R&eacute;f&eacute;rence CNSS</label> 
                        <?php echo form_input("Infos[RefINSS]", set_value("Infos[RefINSS]", isset($infos['RefINSS']) ? $infos['RefINSS'] : ""), 'class="form-control" '); ?>
                    </div>
                </div> 
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="QuotasONEM">Quota DGI</label> 
                        <?php echo form_input("Infos[QuotasDGI]", set_value("Infos[QuotasDGI]", isset($infos['QuotasDGI']) ? $infos['QuotasDGI'] : ""), 'class="form-control" id="quota_dgi"'); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="QuotasONEM">Quatas ONEM</label> 
                        <?php echo form_input("Infos[QuotasONEM]", set_value("Infos[QuotasONEM]", isset($infos['QuotasONEM']) ? $infos['QuotasONEM'] : ""), 'class="form-control" id="quota_onem"'); ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="QuotasINPP">Quotas INPP</label> 
                        <?php echo form_input("Infos[QuotasINPP]", set_value("Infos[QuotasINPP]", isset($infos['QuotasINPP']) ? $infos['QuotasINPP'] : ""), 'class="form-control" id="quota_inpp" '); ?>
                    </div>
                </div> 
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="QuotasINSS">Quotas CNSS</label> 
                        <?php echo form_input("Infos[QuotasINSS]", set_value("Infos[QuotasINSS]", isset($infos['QuotasINSS']) ? $infos['QuotasINSS'] : ""), 'class="form-control" id="quota_inss" '); ?>
                    </div>
                </div> 
            </div>
        </div>
    </div>

    <!-------------------------  DGI Vente des plaques  ------------------------------>
    <div id="DGIVenteplaque" style="<?php echo (isset($encaissement->Typerecette_17) && ($encaissement->Typerecette_17 == "REIMATTRIC"|| $encaissement->Typerecette_17 == "IMMATRIC" || $encaissement->Typerecette_17 == "MUTATION" )) ? '' : 'display: none;'; ?>">
        <div class="row"><div class="col-md-12"><br/><label class="f12 text-black"><b>Partie 4 : Informations additionnelle</b></label><br/></div></div>
        <div class="row">
            <div class="col-md-4">
                <div class="form-group">
                    <label for="MontantTresor">Montant Tresor</label> 
                    <?php echo form_input("Infos[MontantTresor]", set_value("Infos[MontantTresor]", isset($infos['MontantTresor']) ? $infos['MontantTresor'] : ""), 'class="form-control" id="montant_tresor" '); ?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="MontantSYNTELL">Montant SYNTELL</label> 
                    <?php echo form_input("Infos[MontantSYNTELL]", set_value("Infos[MontantSYNTELL]", isset($infos['MontantSYNTELL']) ? $infos['MontantSYNTELL'] : ""), 'class="form-control" id="montant_syntell"'); ?>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="MontantUTSCH">Montant UTSCH</label> 
                    <?php echo form_input("Infos[MontantUTSCH]", set_value("Infos[MontantUTSCH]", isset($infos['MontantUTSCH']) ? $infos['MontantUTSCH'] : ""), 'class="form-control" id="montant_utsch"'); ?>
                </div>
            </div>
        </div> 
        <div class="row">
            <div class="col-md-3">
                <div class="form-group">
                    <label for="MontantDGI">Montant DGI</label> 
                    <?php echo form_input("Infos[MontantDGI]", set_value("Infos[MontantDGI]", isset($Infos['MontantDGI']) ? $Infos['MontantDGI'] : ""), 'class="form-control" id="montant_dgi" '); ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="MontantSONAS">Montant SONAS</label> 
                    <?php echo form_input("Infos[MontantSONAS]", set_value("Infos[MontantSONAS]", isset($Infos['MontantSONAS']) ? $Infos['MontantSONAS'] : ""), 'class="form-control" id="montant_sonas"'); ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="MontantHOLOGRAMME">Montant HOLOGRAMME</label> 
                    <?php echo form_input("Infos[MontantHOLOGRAMME]", set_value("Infos[MontantHOLOGRAMME]", isset($Infos['MontantHOLOGRAMME']) ? $Infos['MontantHOLOGRAMME'] : ""), 'class="form-control" id="montant_hologramme"'); ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="form-group">
                    <label for="MontantRTNC">Montant RTNC</label> 
                    <?php echo form_input("Infos[MontantRTNC]", set_value("Infos[MontantRTNC]", isset($Infos['MontantRTNC']) ? $Infos['MontantRTNC'] : ""), 'class="form-control" id="montant_rtnc"'); ?>
                </div>
            </div> 
        </div>
    </div>

    <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
    <div class="row">
        <div class="col-md-12"><br/><label class="page-header">Partie additionnelle : Frais liés aux attestations</label><br /></div>
    </div>
    <div class="row">
        <div class="col-md-5">
            <div class="form-check abc-checkbox abc-checkbox-success">
                <input class="form-check-input" id="print_attestation" <?= (isset($infos['PaidATTESTATION']) && $_SESSION['Logiref_role'] != 4) || (isset($encaissement->Printattestation_57) && $encaissement->Printattestation_57 >= 1) ? "disabled":""; ?> type="checkbox" <?= isset($infos['PaidATTESTATION']) ? "checked" : "" ?>  name="Infos[PaidATTESTATION]" value="<?= isset($infos['PaidATTESTATION']) ? $infos['PaidATTESTATION'] : "" ?>" >
                <label class="form-check-label text-blue font-bold" for="print_attestation">
                    Frais liés à l’impression de l'attestations
                </label>
            </div>
        </div>
        <div class="col-md-7">
            <div class="form-check abc-checkbox">
                <input 
                    class="form-check-input" id="print_duplicata" type="checkbox" 
                    <?= ( $disableButtons || $_SESSION['Logiref_role'] == 4) || 
                    ($_SESSION['Logiref_role'] != 4 && isset($encaissement->Printattestation_57) && $encaissement->Printattestation_57 == 0) 
                    ? "disabled":"" ?>  
                    name="Infos[PaidDUPLICATA]" 
                    value="<?= isset($infos['PaidDUPLICATA']) ? $infos['PaidDUPLICATA'] : "" ?>"
                >
                <label class="form-check-label text-blue font-bold" for="print_duplicata">
                    Frais de duplicata d’attestation
                </label>
            </div>
        </div>
    </div>
    <?php endif ?>
           

    <!------------------------- Repartitions  ------------------------------>
    <div class="row">
        <div class="col-md-12"><br /><label>Sch&eacute;ma de comptabilisation </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
    </div>
    <div class="row"><div class="col-md-12" id="loader_scheme"></div></div>
    <div class="row">
        <div id="Comptabilisation" class="col-md-12"></div>

    </div>

    <!-------------------------  END  ------------------------------>
</div>
<div class="box-footer clearfix">
    <div class="row">
        <div id="createPaiement" class="col-md-12">

        <!-------------------------  Paiement en attente de validation  du taux ------------------------------>

        <?php if ($_SESSION['Logiref_role'] == 3 && isset($options['ALL']['client-exchange-rate-override']) && isset($encaissement->Tauxflag_58) && $encaissement->Tauxflag_58 == "1"): ?>
            <button type="button" id="validate" <?= ($encaissement->Tauxflag_58 == "0")? 'disabled':''; ?> class="btn btn-success pull-left"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button"  id="dismissal" class="btn btn-danger"><i class="fa fa-print"></i>&nbsp;&nbsp;~Rejet ce paiement&nbsp;</button>&nbsp;&nbsp;
        <?php endif; ?>
        
        <!-------------------------  Paiement en attente de validation  ------------------------------>
        <?php if ($encaissement->Checkerid_10 == 0 && ($maker == $userid || $_SESSION['Logiref_role'] != 4)) : ?>
            <?php if ($_SESSION['Logiref_role'] != 5) : ?>
                <button type="submit" id="enregistrer" <?php if($compte_undefined == true && $_SESSION['Logiref_role'] != '4') echo 'disabled'; ?> class="btn btn-success pull-left <?= $noneButton;  ?>"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) echo "Valider";
                else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="delete" class="btn btn-danger <?= $noneButton;  ?>"><i class="fa fa-print"></i>&nbsp;&nbsp;Supprimer ce paiement&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <?php endif; ?>

            <!-- <button id="reject" type="button" data-target="#prompt_model" data-toggle="modal" class="btn btn-danger btn-sm" <?php if($encaissement->Status_2 !=6) echo 'disabled'; else echo ''; ?>><i class="fa fa-trash"></i>&nbsp;&nbsp;Rejeter ce paiement</button> -->
            <button type="button" id="print" disabled="disabled" class="btn btn-primary <?= $noneButton;  ?>"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" id="schema" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le sch&eacute;ma comptable &nbsp;&nbsp;</button>&nbsp;&nbsp;
        <?php endif; ?>

        <!-------------------------  Paiement validE  ------------------------------>
        <?php if ($encaissement->Checkerid_10 > 0 && ($maker == $userid || $_SESSION['Logiref_role'] != 4)) : ?>
            <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                <?php if (($encaissement->Printattestation_57 == 0 && isset($infos['PaidATTESTATION']) && !isset($infos['PaidDUPLICATA']))): ?>
                <!-- <php if (($encaissement->Printattestation_57 == 0 && isset($infos['PaidDUPLICATA']) && !isset($infos['PaidDUPLICATA']))): ?> -->
                    <button type="button" id="paid_attestation" class="btn btn-success d-none"><i class="fa fa-save"></i>&nbsp;&nbsp;Payer le duplicata&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <?php else : ?>
                    <button type="button" id="paid_attestation" class="btn btn-success d-none"><i class="fa fa-save"></i>&nbsp;&nbsp;Payer le duplicata&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <?php endif; ?>

                <button type="button" id="treat" class="btn btn-primary d-none"><i class="fa fa-repeat "></i>&nbsp;&nbsp;Traiter&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <?php endif; ?>

            <button type="submit" id="enregistrer" disabled="" class="btn btn-success"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) echo "Valider"; else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
            <button type="button" disabled="" id="delete" class="btn btn-danger"><i class="fa fa-print"></i>&nbsp;&nbsp;~Supprimer ce paiement&nbsp;</button>&nbsp;&nbsp;
        <?php endif; ?>

        <?php if ($encaissement->Checkerid_10 > 0): ?>
            <button type="button" id="schema" class="btn btn-primary">
                <i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le schéma comptable&nbsp;&nbsp;
            </button>&nbsp;&nbsp;

            <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                <?php if ((isset($infos['PaidATTESTATION'])) && !$disableAttestation): ?>
                    <button type="button" id="print" class="btn btn-primary">
                        <i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;
                    </button>&nbsp;&nbsp;
                <?php else: ?>
                    <button type="button" id="print" disabled class="btn btn-primary">
                        <i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;
                    </button>&nbsp;&nbsp;
                <?php endif; ?>
            <?php else : ?>
                <button type="button" id="print" class="btn btn-primary">
                    <i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;
                </button>&nbsp;&nbsp;
            <?php endif; ?>
        <?php endif; ?>

        <a id="" type="button" href="" class="btn btn-warning"><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
    </div>

    </div>
</div>

<?php $chtml->box_body_closing(); ?>

<!-- Modal -->
<div class="modal fade" id="prompt_model" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Rejet de paiement</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="form-group">
              <label for="motif">Motif de rejet du paiement</label>
              <input type="text" id="motif" style="width: 100%;outline: none;padding: 5px;"/>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
        <button type="button" id="btn-reject" class="btn btn-danger"><i class="fa fa-trash"></i>&nbsp;&nbsp;Rejeter ce paiement</button>
      </div>

    </div>
  </div>
</div>
<?php echo form_close();?>
<!-------------------------  Section identique a Step 2  ------------------------------>
<script type="text/javascript" charset="utf-8">
    
    $(".select2").select2();
    
    $("#pager").on("change", "#dgi_unique", function(){
        
        if ($(this).is(":checked")) 
        {
            html_cotisation = $("#dgi_cotisation_avec_institution").html();
            $("#dgi_cotisation_avec_institution").css('display', 'none');
            $("#dgi_cotisation_avec_institution").html('');
            $("#dgi_cotisation_unique").css('display', '');
            $("#dgi_cotisation_unique").html(html_dgi_unique);
        }
        else
        {
            $("#dgi_cotisation_avec_institution").css('display', '');
            $("#dgi_cotisation_unique").html('');
            $("#dgi_cotisation_avec_institution").html(html_cotisation);
        }
    });
    
    
    var ref = '<?php echo $encaissement->Id_0; ?>';
    var html_cotisation = $("#DGICotisation").html();
    var html_dgi_unique = $("#dgi_cotisation_unique").html();
    var html_venteplaque = $("#DGIVenteplaque").html();
    
    var controller = '<?php echo isset($controller) ? $controller : ""; ?>';
    var from = '<?php echo isset($from) ? $from : ""; ?>';
    var taux = '<?= isset($taux['Dollar_4']) ? $taux['Dollar_4'] : ""; ?>';
    var bank = '<?php echo $bank; ?>';

    var montant_total = '';
	
	'<?php if($compte_undefined == true): ?>'
		$('#message').html('<div class="alert aDanger text-white"> L\'un des comptes recepteurs des fonds n\'est pas param&eacute;tr&eacute;, veuillez contacter votre administrateur quant &agrave; ce.</div>');
	'<?php endif; ?>'

    $("#contenter").on("click", "#close_form", function() {
        close_form();
    });

    '<?php if (isset($options['ALL']['internal-account-from-cash-mode']) && isset($infos['accountType']) && $infos['accountType'] == "MAD"): ?>';
        get_accountinternal();
    '<?php elseif (isset($infos['CustomerNumber'])  && $infos['CustomerNumber'] !="" ): ?>';
        get_customeraccounts();
    '<?php else: ?>';
        get_accountname();
    '<?php endif; ?>';
    
    //Datepicker
    $('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker3').datepicker({
        todayHighlight: true,
        format: 'mm-yyyy'
    });
    
    
    $("#pager").on("change", "#quota_dgi", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#quota_onem", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#quota_inpp", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#quota_inss", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#montant_tresor", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });


    $("#pager").on("change", "#montant_hologramme", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });


    $("#pager").on("change", "#montant_sonas", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });


    $('#montantNote').on("keyup", function() {
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#montant_dgi", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#montant_syntell", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#montant_utsch", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $("#pager").on("change", "#montant_rtnc", function(){
        var amount = $(this).val();
        this.value = format_amount(amount);
    });


    $('#recetteMontant').on("keyup", function() {
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $('#commission').on("keyup", function() {
        var amount = $(this).val();
        this.value = format_amount(amount);
    });

    $('#montantNote').change(function(){
        var note = $('#montantNote').val();
        var deviseNote = $('#deviseNote option:selected').val();
        
        $('#montantNote').val(note);
        $('#recetteMontant').val(note);
        
        if(note !="")
        {
            <?php if(isset($options['ALL']['client-exchange-rate-override'])): ?>
                handle_exchange_rate(true) 
            <?php endif; ?>

            note = parseFloat($('#montantNote').val().split(' ').join('').split(',').join('.'));

            if(deviseNote == 'USD')
            {
                note = note * taux;
                note = Number(note).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                $('#montantTotal').val(note);
            }
            else
            {
                note = Number(note).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                $('#montantTotal').val(note);
            }

            $('#commission').val('');
            commission();
        }
    });

    $('#deviseNote').change(function(){
        var devise = $('#deviseNote option:selected').val();
        var note = $('#montantNote').val();
        var mode = $('#modeId option:selected').val();
        $('#recetteDevise').val(devise);
        $('#totalDevise').val('CDF');
        
        if(devise !="")
        {
            <?php if(isset($options['ALL']['client-exchange-rate-override'])): ?>
                handle_exchange_rate(true) 
            <?php endif; ?>

            note = parseFloat(note.split(' ').join('').split(',').join('.'));
            if(devise == 'USD')
            {
                note = note * taux;
                note = Number(note).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                if(note) $('#montantTotal').val(note);
            }
            else
            {
                note = Number(note).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                if(note) $('#montantTotal').val(note);
            }

            $('#commission').val('');

            commission();

            '<?php if(isset($options['ALL']['internal-account-from-cash-mode'])): ?>';
                if(mode == '5')
                {
                    get_accountinternal();
                }
            '<?php endif; ?>';
        }
    });

    <?php if(isset($options['ALL']['client-exchange-rate-override'])): ?>
        $("#Taux").change(function(){
            var note = $('#montantNote').val();
            var deviseNote = $('#deviseNote option:selected').val();
            var tauxModif = parseFloat($('#Taux').val().split(' ').join('').split(',').join('.'));
           
            $('#recetteMontant').val(note);
            
            if(note !="" && deviseNote != "")
            {
                handle_exchange_rate(false) 

                $('#commission').val('');
                commission();
            }
        });
    <?php endif; ?>

    $('#recetteMontant').change(function(){
    
        var montant = $('#recetteMontant').val();
        var note = $('#montantNote').val();
        
        var deviseNote = $('#deviseNote option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        $('#recetteDevise').val(deviseNote);
        
        if(montant !="")
        {
            montant = parseFloat(montant.split(' ').join('').split(',').join('.'));
            note = parseFloat(note.split(' ').join('').split(',').join('.'));

            if(montant > note)
            {
                $('#info').html('Montant; &agrave; payer sup&eacute;rieur au montant de la note!');
            }
            else
            {
                var commissions = $("#commission").val();

                if(commissions !='0' && commissions !='')
                {
                    commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));

                    if(deviseNote=='USD')
                    {
                        montant = montant * taux;

                        montant = commissions + montant + (commissions *0.16);
                        montant = Number(montant).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                        $('#montantTotal').val(montant);
                    }
                    else
                    {
                        montant = commissions + montant + (commissions *0.16);
                        montant = Number(montant).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                        $('#montantTotal').val(montant);
                    }
                }
                else
                {
                    if(recetteDevise == 'USD')
                    {
                        montant = montant * taux;
                        montant = Number(montant).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                        $('#montantTotal').val(montant);
                    }
                    else
                    {
                        montant = Number(montant).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                        $('#montantTotal').val(montant);
                    }
                }

                $('#info').html('');
                commission();
            } 
        }
    });

    $('#recetteDevise').change(function() {
        commission();
    });

    $('#service').change(function() {
        commission();
    });
    
    $('#modeId').change(function() {

        $("#loader-sub-menu").html('');
        
        var mode = $('#modeId option:selected').val();
        
        if(mode == '5')
        {
            '<?php if(isset($options['ALL']['internal-account-from-cash-mode'])): ?>';
                get_accountinternal();
            '<?php endif; ?>';
        }
        else
        {
            $("#compteId").val(''); 
            $("#compteDevise").val('');
            $("#accountname").html('');
        }
        
        $('#commission').val('');
        commission();
    });

    $('#commission').change(function(){
        var commissions = $("#commission").val();
        var devise = $('#recetteDevise').val();
        var montant = $('#recetteMontant').val();
        
        if(commissions !='0' && commissions !='')
        {
                commissions = parseFloat($("#commission").val().split(' ').join('').split(',').join('.'));
                
                montant = parseFloat(montant.split(' ').join('').split(',').join('.'));

                if(devise == 'USD')
                {
                    montant = montant * taux;
                    montant = montant + commissions + (commissions *0.16);
                    montant = Number(montant).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " "); 
                    $('#montantTotal').val(montant);
                }
                else
                {
                    montant = montant + commissions + (commissions *0.16);
                    montant = Number(montant).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                    $('#montantTotal').val(montant);
                }
        }
        else if(commissions=='0' || commissions=='')
        {
                if(devise == 'USD')
                {
                    montant = montant * taux;
                    montant = Number(montant).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                    $('#montantTotal').val(montant);
                }
                else
                {
                    montant = Number(montant).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                    $('#montantTotal').val(montant);
                }
        }

        update_montant_total_final();
    });

    $("#pager").on("change", "#recette", function() {
        commission();

        var recette = $('#recette option:selected').val();
        if (recette === 'IPRIER'  || recette === 'IRPPDR11') {
            $("#DGICotisation").css('display', '');
        } else {
            $("#DGICotisation").css('display', 'none');
        }
        
           	
        if(recette ==='REIMATTRIC' || recette ==='IMMATRIC' || recette ==='MUTATION')
        {
            $("#DGIVenteplaque").css('display', '');
            //$("#DGIVenteplaque").html(html_venteplaque);
        }
        else
        {
            $("#DGIVenteplaque").css('display', 'none');
            //$("#DGIVenteplaque").html('');
        }
    });

    $('#form').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        
        var data = $(this).serialize();

        var devise = $('#deviseNote option:selected').val();
        var compteDevise = $('#compteDevise option:selected').val();
        var commissionDevise = $('#commissionDevise option:selected').val();
        var totalDevise = $('#totalDevise option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        var mode = $('#modeId option:selected').val();
        var commission_value = $('#commission').val();
        
        '<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) : ?>'
        
            $("#enregistrer").prop("disabled", true);
            $("#reject").prop("disabled", true);

        '<?php endif; ?>';
        
        scrollUP();

        '<?php if(isset($encaissement->Id_0) && $encaissement->Id_0 !=""){ ?>'
        
            var recette = '<?= $encaissement->Typerecette_17; ?>'
            
            
        '<?php }else{ ?>'
        
            var recette = $('#recette option:selected').val();
            
        '<?php } ?>'

        if(recette == 'IPRIER'  || recette === 'IRPPDR11')
        {
            var verif_iprier = verify_iprier_amount();
            
            if(verif_iprier)
            {
                get_account_balance(data);
            }
            else
            {
                if($('#dgi_unique').is(":checked"))
                {
                    $('#loader-sub-menu').html('<div class="alert aDanger text-white"> Le montant &agrave; payer n\'est pas &eacute;gal au montant saisi dans le champ Quota DGI.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else
                {
                    $('#loader-sub-menu').html('<div class="alert aDanger text-white"> Le montant &agrave; payer n\'est pas &eacute;gal &agrave; la somme de quotas des diff&eacute;rentes instutitions. (Veuillez saisir le montant 0 dans le champ réservé au quota d\'une institution si cette dernière n\'est pas reprise dans la déclaration).<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            }
        }
        else
        {
            get_account_balance(data);
        }
    });
    
    $("#compteId").change(function() {
        
        var bank = '<?php echo $bank; ?>';
        
        if(bank == '@boa')
        {
            var compte = $(this).val();

            if (compte.length < 18) 
            {
                $("#accountname").removeClass('text-black');
                $("#accountname").removeClass('text-green');
                $("#accountname").addClass('text-red');
                $("#accountname").text('Numéro de compte invalide');
                $("#compteId").val('');
            } 
            else 
            {
                get_accountname();
            }
        }
        else
        {
            get_accountname();
        }
        commission();
        
    });

    '<?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>'
        $("#customerNumber").change(function(){
            var customer_number = $(this).val();

            if (customer_number.length <= '7') 
            {
                get_customeraccounts()
            }
        });
    '<?php endif; ?>';

    $("#compteDevise").change(function() {
        get_accountname();
        commission();

        <?php if(isset($options['ALL']['client-exchange-rate-override'])): ?>
            handle_exchange_rate(true) 
        <?php endif; ?>
    });

    $("#cancel").click(function() {
        location.reload(true);
    });

    $(document).on('change', '#compteId', function () {
        
        $("#accountname").html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');

        const selected = $(this).find(':selected');
        const name = selected.data('name');
        const currency_code = selected.data('currency');
        const balance = selected.data('balance');
        const type = selected.data('type');

        if (!selected.val()) {
            $('#accountname').html('');
            $('#account_name, #account_currency, #account_balance, #account_type').val('');
            $('#compteDevise').val('').trigger('change');
            return;
        }

        const mapped_currency = {
            '976': 'CDF',
            '840': 'USD'
        };

        const currency = mapped_currency[currency_code];

        // Ajoute un délai avant d'afficher les infos
        setTimeout(function () {
            $('#accountname').removeClass().addClass('text-green').html(name);
            $('#account_name').val(name);
            $('#account_currency').val(currency);
            $('#account_balance').val(balance);
            $('#account_type').val(type);

            if (currency) {
                $('#compteDevise').val(currency);
                $('#compteDevise').prop('disabled', true);

                // Supprime tout champ hidden existant pour éviter les doublons
                $('input[name="Devise_34"]').remove();

                // Ajoute un input hidden pour l'envoi correct de la valeur
                $('<input>').attr({
                    type: 'hidden',
                    name: 'Devise_34',
                    value: currency
                }).appendTo('form');
            }
        }, 2000);
    });

    $("#pager").on("click", "#treat", function(event){
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        scrollUP(); 

        $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxnotes/display/instructions_attestation'); ?>/<?php echo $encaissement->Id_0; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        var data = $("#form").serialize();

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                if(result.code =='E200'){
                        $('#message').html('');

                        $("#treat").removeClass('d-none');
                        $("#treat").prop("disabled", true);
                        $("#print").prop("disabled", true);
                        $("#paid_attestation").removeClass('d-none');

                        comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');

                        $('#message').html('<div class="alert alert-info text-black"> Le traitement a été effectué avec succès. Veuillez valider les frais afin de pouvoir imprimer l\'attestation.!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                } else if (result.code == "E405") {
                        $("#treat").prop("disabled", true);
                        $("#paid_attestation").removeClass('d-none');

                        $('#message').html('<div class="alert alert-info text-black"> L\'attestation ne peut pas être imprimée tant que des écritures restent en attente de validation. Merci de valider les frais concernés.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else {
                        $('#message').html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, veuillez refaire le traitement s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error: function(error) {
                $('#enregistrer').prop("disabled", false);
                $('#message').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    $("#pager").on("click", "#paid_attestation", function(event){
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        scrollUP(); 

        $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxnotes/save/paid_attestation'); ?>/<?php echo $encaissement->Id_0; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        var data = $("#form").serialize();

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                    if(result.code =='E407')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#loader').prop("disabled",true);
                        $('#enregistrer').prop("disabled", false);
                    }
                    else if(result.code =='E408')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Désolé, vous n\'êtes pas habilité à valider ce paiement suivant votre rôle, veuillez contacter votre administrateur s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#loader').prop("disabled",true);
                        $('#enregistrer').prop("disabled", false);
                    }
                    else if(result.code =='E409')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Paiement non validé, erreur des données invalides.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#loader').prop("disabled",true); 
                        $('#enregistrer').prop("disabled", false);  
                    }
                    else if(result.code =='200')
                    {
                        $('#message').html(result.msg);

                        $('#enregistrer').prop("disabled", true);
                        $('#delete').prop("disabled",true); 

                        $("#paid_attestation").prop("disabled", true);
                        $('#print').prop("disabled",false); 
                        comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');
                    }
                    else 
                    {
                        $("#loader-sub-menu").html('');
						$('#message').html(result.msg);
                        $('#enregistrer').prop("disabled", false);
                        //$("#message").html('<div class="alert aDanger text-white"> L\'envoi des &eacute;critures &agrave; au corebanking fait avec succ&egrave;s, mais cependant l\'intégration de quelques &eacute;critures n\'ont pas abouti, veuillez trouver ce paiement dans le menu regularisation pour le regulariser<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            },
            error: function(error) {
                $('#enregistrer').prop("disabled", false);
                $('#message').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

   <?php if (isset($options['ALL']['client-exchange-rate-override'])): ?>
    $("#pager").on("click", "#validate", function(event){
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        scrollUP(); 

        $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxnotes/save/payment_validate_taux'); ?>/<?php echo $encaissement->Id_0; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';
        var data = $("#form").serialize();

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                if(result.code =='E200'){
                        $('#message').html('');
                        $("#loader2").html('');

                        //$("#validate").prop("disabled", true);
                        //$("#dismissal").prop("disabled", true);
                        $("#validate").addClass("d-none");
                        $("#dismissal").addClass("d-none");

                        $("#enregistrer").removeClass("d-none");
                        $("#delete").removeClass("d-none");
                        $("#print").removeClass("d-none");
                        $('#message').html(
                            '<div class="alert aSuccess text-white">' +
                                'Le taux a été traité et confirmé avec succès. ' +
                                'Veuillez valider ce paiement.' +
                                '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>' +
                            '</div>'
                        );

                } else if (result.code == "E405") {
                        $("#validate").prop("disabled", true);
                        $("#dismissal").prop("disabled", true);
                        $('#message').html('<div class="alert aDanger text-white"> Accès refusé : vous ne disposez pas des droits nécessaires pour valider le taux de change pour ce type de paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else {
                        $("#validate").prop("disabled", false);
                        $("#dismissal").prop("disabled", false);
                        $('#message').html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, Le taux est correct, mais la validation n’a pas pu être effectuée. Merci de réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error: function(error) {
                $('#enregistrer').prop("disabled", false);
                $('#message').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    $("#pager").on("click", "#dismissal", function(event){
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();

        scrollUP();

        var pid = '<?php echo $encaissement->Id_0; ?>';

        swal({
                title: "REJET",
                text: "Etes-vous sûr de vouloir rejeter ce paiement ?",
                type: "warning",
                showCancelButton: true,
                cancelButtonText:"Non",
                confirmButtonText: "Oui",
                closeOnConfirm: true,
                confirmButtonColor: "#c9302c"
            },function(isConfirm){
                if(isConfirm) {
                    var url = '<?php echo base_url($module . '/taxnotes/save/payment_dismissal_taux'); ?>/' + pid;
                    scrollUP();
                    $.ajax({
                        type: 'GET',
                        url: url,
                        dataType: 'json',
                        encode: true,
                        success: function(result) {

                            if(result.code =='E200'){
                                    $('#message').html('');

                                    $("#validate").prop("disabled", true);
                                    $("#dismissal").prop("disabled", true);
                                    $('#message').html('<div class="alert aSuccess text-white">Rejet confirmé ! Le taux appliqué n’est pas valide et doit être mis à jour par l’opérateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');

                            } else if (result.code == "E405") {
                                    $("#validate").prop("disabled", true);
                                    $("#dismissal").prop("disabled", true);
                                    $('#message').html('<div class="alert aDanger text-white"> Accès refusé : vous ne disposez pas des droits nécessaires pour valider le taux de change pour ce type de paiement.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else {
                                    $("#validate").prop("disabled", false);
                                    $("#dismissal").prop("disabled", false);
                                    $('#message').html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, Le taux est correct, mais la validation n’a pas pu être effectuée. Merci de réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                        },
                        error: function(error) {
                            $('#enregistrer').prop("disabled", false);
                            $('#message').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                    });
                }
        });
    });
    <?php endif; ?>

    <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
        handle_checkbox_value("#print_attestation", "FIA");
        handle_checkbox_value("#print_duplicata", "FDA");

        function handle_checkbox_value(selector, valueIfChecked) {
            $(selector).on("change", function () {
                const isChecked = $(this).is(':checked');
                $(this).val(isChecked ? valueIfChecked : "");

                $("#commission").val('');
                commission();

                <?php if (isset($encaissement->Checkerid_10) && $encaissement->Checkerid_10 > 0): ?>
                    if(isChecked){
                        $("#treat").removeClass("d-none");
                        $("#enregistrer").addClass("d-none");
                        $("#delete").addClass("d-none");
                    }else {
                        $("#treat").addClass("d-none");
                        $("#enregistrer").removeClass("d-none");
                        $("#delete").removeClass("d-none");
                    }
                <?php endif; ?>
            });
        }

        function commission_attestation() 
        {
            var print_type = $("#print_attestation").val();
            var regie = 'DGI';
            var montant = $('#recetteMontant').val();
            var devise = $('#recetteDevise option:selected').val();
            var commission = $("#commission").val();
            var taux = $('#Taux').val();
            var csrf = $('input[name="csrf_name"]').val();

            $("#enregistrer").prop('disabled', true);

            if (montant !== '' && devise !== '') {
                var url = '<?php echo base_url('admin/fees/display/'); ?>/impression_fees<?php echo $encaissement->Id_0 > 0 ? '/'.$encaissement->Id_0 : ''; ?>';
                
                commission = commission ? parseFloat(commission.toString().replace(/\s+/g, "")) : 0;
                montant    = montant ? parseFloat(montant.toString().replace(/\s+/g, "")) : 0;

                $.ajax({
                    type: 'POST',
                    url: url,
                    data: {
                        print_type: print_type,
                        regie: regie,
                        montant: montant,
                        commission : commission,
                        devise: devise,
                        taux: taux,
                        csrf_name:csrf
                    },
                    dataType: 'html',
                    encode: true,
                    success: function(reponse) {

                        const result = JSON.parse(reponse);

                        const commission1 = result[0] ? parseFloat(result[0]) : 0;
                        const montant1    = result[2] ? parseFloat(result[2]) : 0;

                        const comm_total    = commission + commission1;
                        const montant_total = commission + montant1;

                        // Formatage
                        const formattedCommission = Number(commission1).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                        const formattedMontant    = Number(montant_total).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");

                        $("#commissionAttestation").val(formattedCommission);
                        //$("#commissionDevise").val(result[1]);
                        $("#montantTotal").val(formattedMontant);

                        $("#enregistrer").prop('disabled', false);

                        update_montant_total_final();
                    },
                    error: function(error) {
                        $('#bl').html('');
                        $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                });
            }
        }
    <?php endif; ?>

    function commission() 
    {
        $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        $("#commission").val('');
        $("#Devise_24").prop("selectedIndex", 0);
        
        var mode = $('#modeId option:selected').val();
        var montant = $('#recetteMontant').val();
        var regie = 'DGI';
        var commission = $("#commission").val();
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var compte = $('#compteId').val();
        var guichet = $('#guichetId').val();
        var taux = $('#Taux').val();
        var csrf = $('input[name="csrf_name"]').val();

        if (montant !== '' && devise !== '' && service !== '') {

            var url = '<?php echo base_url('admin/fees/display/default'); ?>/<?php echo $encaissement->Id_0; ?>';
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    mode: mode,
                    regie: regie,
                    service: service,
                    recette: recette,
                    devise: devise,
                    montant: montant,
                    guichet: guichet,
                    compte : compte,
                    taux: taux,
                    csrf_name:csrf
                },
                dataType: 'html',
                encode: true,
                success: function(reponse) {
                    var result = JSON.parse(reponse);

                    if (commission == '' || commission == '0') {
                        $('#message').html('');

                        const formattedCommission = Number(result[0]).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                        const formattedMontant    = Number(result[2]).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");

                        <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                            if ($("#print_attestation").is(':checked')) {
                                $("#commission").val(formattedCommission);
                                $("#commissionDevise").val(result[1]);

                                commission_attestation();
                            } else {

                                $("#commission").val(formattedCommission);
                                $("#commissionDevise").val(result[1]);

                                $("#commissionAttestation").val(0);
                                
                                $("#montantTotal").val(formattedMontant);
                            }
                        <?php else : ?>
                            $("#commission").val(formattedCommission);
                            $("#commissionDevise").val(result[1]);

                            $("#montantTotal").val(formattedMontant);
                        <?php endif; ?>
                    }

                    update_montant_total_final();

                },
                error: function(error) {
                    $('#bl').html('');
                    $('#message').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }
    }

    function get_account_balance(data)
    {
        var compte = $('#compteId').val();
        var devise = $('#recetteDevise option:selected').val();
        var montant = $('#recetteMontant').val();
        var commission = $('#commission').val();
        var devise_commission = $('#commissionDevise').val();
        var devise_compte = $('#account_currency').val();
        var balance = $('#account_balance').val();
        var csrf = $('input[name="csrf_name"]').val();
        
        if (balance == "no-verification-balance")
        {
            submiter(data);
        }
        else
        {
            var url = '<?php echo base_url('branch/taxaccounts/data/get_account_balance'); ?>';

            $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : { compte : compte, devise : devise, montant : montant, commission : commission, devise_commission : devise_commission, devise_compte : devise_compte, balance : balance, csrf_name:csrf}, 
                dataType    : 'html',  
                encode          : true,
                success: function(reponse)
                {
                    if(reponse == '200')
                    {
                        submiter(data);
                    }

                    else if(reponse == '300')
                    {
                        $('#message').html('<div class="alert aDanger text-white"> Solde du compte insuffisant pour le paiement de cette d&eacute;claration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else if(reponse == '405')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Veuillez renseigner toules les informations requises s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                    else
                    {
                        $('#message').html('<div class="alert aDanger text-white">Alerte: Probl&eacute;me de connexion au core banking, survenu lors de la recup&eacute;ration de la balance du compte du client. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
                },
                error:function(error)
                {
                    $('#message').html('<div class="alert aWarning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }  
            });
        }
    }
    
    function get_accountinternal() 
    {
        var mode = $('#modeId option:selected').val();
        var devise = $('#deviseNote option:selected').val();
        var regie = 'DGI';
        var csrf = $('input[name="csrf_name"]').val();
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountinternal'); ?>';
        
        if (devise !== '' && mode !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    devise: devise,
                    regie: regie,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {

                    $("#loader-sub-menu").html('');

                    const input_html = '<input type="text" name="Compte_33" value="" class="form-control form-control-md" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26">';
                    $('#compteId').replaceWith(input_html);
                    
                    if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le compte n&apos;existe pas');
                    }
                    else
                    {
                            if (reponse.account ===  '000000000000000000000000')
                            {
                                    $("#accountname").removeClass('text-black');
                                    $("#accountname").removeClass('text-green');
                                    $("#accountname").addClass('text-yellow');
                                    $("#accountname").html("Le compte interne n’a pas été paramétré pour cette agence");
                                    
                                    $("#compteId").val(reponse.account).css("color", "red");

                                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Le compte interne n’a pas été paramétré pour cette agence<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else
                            {
                                    $("#accountname").removeClass('text-black');
                                    $("#accountname").removeClass('text-yellow');
                                    $("#accountname").addClass('text-green');
                                    $("#accountname").html("Compte interne");
                                    $("#account_name").val("Compte interne");
                                    $("#account_type").val("MAD");
                                    $("#account_currency").val(reponse.currency);
                                    
                                    $("#account_balance").val("no-verification-balance");
                                    
                                    $("#compteId").val(reponse.account);
                                    $("#compteDevise").val(reponse.currency);
                            }
                    }
                },
                error: function(error) {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }
    
    function get_accountname() 
    {
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();
        var core_banking = '<?php echo $core_banking; ?>';
        
        var url = '<?php echo base_url('branch/taxaccounts/data/get_accountname'); ?>';
        
        if (compte !== '' && devise !== '') {
            $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    compte: compte,
                    devise: devise,
                    csrf_name:csrf
                },
                dataType: 'json',
                encode: true,
                success: function(reponse) {
                    
                    if(reponse.code == '404')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Ce compte n&apos;existe pas');
                    }
                    else if(reponse.code  == '406')
                    {
                            
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.code  == '405')
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Le format de compte n\'est pas valide');
                    }
                    else if(reponse.currency == null && reponse.account_name == null)
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").removeClass('text-green');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Probl&egrave;me de connexion &agrave; '+core_banking);
                    }
                    else if(reponse.currency != devise)
                    {
                            $("#accountname").removeClass('text-green');
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-red');
                            $("#accountname").html('Devise du compte incorrecte');
                    }
                    else
                    {
                            $("#accountname").removeClass('text-black');
                            $("#accountname").addClass('text-green');
                            $("#accountname").html(reponse.account_name);
                            $("#account_name").val(reponse.account_name);
                            $("#account_currency").val(reponse.currency);
                            $("#account_balance").val(reponse.balance);

                            // Vérifier si branch_code existe avant de l'utiliser
                            if (reponse.branch_code !== undefined && reponse.branch_code !== null) {
                                $("#branch_code").val(reponse.branch_code);
                            }
                    }
                },
                error: function(error) {
                    $('#message').html('<div class="alert aDanger text-white"> La requête a pris beaucoup de temps, veuillez refaire s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        } else {
            $("#accountname").html('');
        }
    }

    function get_account_exemption(callback)
    {
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var csrf = $('input[name="csrf_name"]').val();
        var url = '<?php echo base_url('branch/taxaccounts/data/get_account_exemption'); ?>';

        if (compte === '' || devise === '') {
            if (typeof callback === 'function') callback(null);
            return;
        }

        $.ajax({
            type: 'POST',
            url: url,
            data: { compte: compte, devise: devise, csrf_name: csrf },
            dataType: 'json',
            success: function(reponse) {
                if (reponse.code == '200') 
                {
                    const formattedCommission = Number(reponse.comm).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                    $("#commission").val(formattedCommission);
                    $("#commissionAttestation").val(formattedCommission);
                } 

                if (typeof callback === 'function') callback(reponse);
            },
            error: function() {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                if (typeof callback === 'function') callback(null);
            }
        });
    }

    function get_customeraccounts() 
    {
        const customer_number = $('#customerNumber').val();
        const csrf = $('input[name="csrf_name"]').val();
        const core_banking = '<?php echo $core_banking; ?>';

        const url = '<?php echo base_url('branch/taxaccounts/data/get_customeraccounts'); ?>';

        if (!customer_number) {
            //$("#labelNumber").html('');
            $('#labelNumber').removeClass().addClass('text-red').html("Le numéro est requise");
            return;
        }

        const loader_img = '<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />';
        $("#labelNumber, #compteLabel").html(loader_img);

        $('#compteDevise').prop('disabled', false);

        $.ajax({
            type: 'POST',
            url: url,
            data: {
                customer_number: customer_number,
                csrf_name: csrf
            },
            dataType: 'json',
            encode: true,
            success: function (reponse) {

                if (reponse.code == "200") {

                    <?php if ($encaissement->Compte_33 != "" && $encaissement->Devise_34 != ""): ?>
                        const compte = '<?= $encaissement->Compte_33 ?>';
                        const devise = '<?= $encaissement->Devise_34 ?>';
                    <?php else: ?>
                        const compte = null;
                        const devise = null;
                    <?php endif; ?>

                    const mapped_currency = {
                        '976': 'CDF',
                        '978': 'EUR',
                        '840': 'USD'
                    };

                    let select = $('<select>', {
                        id: 'compteId',
                        name: 'Compte_33',
                        class: 'form-control form-control-md',
                        required: true
                    });

                    select.append('<option value="">Sélectionnez un compte du client</option>');

                    $.each(reponse, function (index, account) {
                        if (!isNaN(index)) {

                            const currency_label = mapped_currency[account.currencyCode] || account.currencyCode;
                            const option_text = `${account.accountNumber} - (${currency_label})`;

                            const is_selected = (compte === account.accountNumber && devise === currency_label);

                            const option = $('<option>', {
                                value: account.accountNumber,
                                text: option_text,
                                'data-name': account.name,
                                'data-currency': account.currencyCode,
                                'data-balance': account.balance,
                                'data-type': account.type,
                                selected: is_selected
                            });

                            select.append(option);
                        }
                    });

                    $('#compteId').replaceWith(select);

                    // Déclenche le changement **seulement** si un compte a été sélectionné automatiquement
                    // if (compte && devise) {
                    //     select.trigger('change');
                    // }
                    select.trigger('change');

                    $("#compteLabel").html('Comptes du client');
                    $("#labelNumber").html('');

                    } else {
                        const input_html = '<input type="text" name="Compte_33" value="" class="form-control form-control-md" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26">';
        
                        $('#compteId').replaceWith(input_html);

                        $("#compteLabel").html('Compte du client');
                        $("#labelNumber").html('');

                        if (reponse.code == '406') {
                            $('#labelNumber').removeClass().addClass('text-red').html("Ce numéro n'existe pas");
                        } else if (reponse.code == '405') {
                            $('#labelNumber').removeClass().addClass('text-red').html("Le format du numéro n'est pas valide");
                        } else if (reponse.code == '404') {
                            $('#labelNumber').removeClass().addClass('text-red').html("Problème de connexion à " + core_banking);
                        }
                    }
            },
            error: function () {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    function submiter(data) {

        $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxnotes/save/comptant'); ?>/<?php echo $encaissement->Id_0; ?>';
        var gid = '<?php echo $encaissement->Id_0; ?>';

        // Manage the message and the button when it's the validator or the supervisor
        var message = '<div class="alert aSuccess text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        '<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) : ?>'
            message = '<div class="alert aSuccess text-white">Bravo! paiement valid&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        '<?php endif; ?>'

        var core_banking = '<?php echo $core_banking; ?>';

        $('#enregistrer').prop("disabled", true);

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(result) {

                $("#loader2").html('');

                '<?php if ($_SESSION['Logiref_role'] == 3 || $_SESSION['Logiref_role'] == 2) : ?>'

                    if(result.code =='E407')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Désolé, l\'option de validation n\'est pas paramétré pour votre compte, veuillez contacter votre administrateur.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#loader').prop("disabled",true);
                        $('#enregistrer').prop("disabled", false);
                    }
                    else if(result.code =='E408')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Désolé, vous n\'êtes pas habilité à valider ce paiement suivant votre rôle, veuillez contacter votre administrateur s\'il vous plaît.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#loader').prop("disabled",true);
                        $('#enregistrer').prop("disabled", false);
                    }
                    else if(result.code =='E409')
                    {
                        $('#message').html('<div class="alert aDanger text-white">Paiement non validé, erreur des données invalides.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#loader').prop("disabled",true);
                        $('#enregistrer').prop("disabled", false);
                    }
                    else if(result.code =='200')
                    {
                        $('#step2').remove;
                        $("#step-2").removeClass('bg-green-active');
                        $("#step-2").addClass('bg-gray');
                        $("#step-3").removeClass('bg-gray');
                        $("#step-3").addClass('bg-green-active');

                        if(result.message != undefined){
                            $('#message').html(result.message);
                        }
                        else{
                            $('#message').html(result.msg);
                        }

                        $('#enregistrer').prop("disabled", true);
                        $('#delete').prop("disabled",true);

                        <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
                            let printed = '<?= isset($infos['PaidATTESTATION']) ? true : false ?>';
                            if (printed) {
                                $('#print').prop("disabled",false);
                            } else {
                                $('#print').prop("disabled",true);
                            }
                        <?php else : ?>
                            $('#print').prop("disabled",false);
                        <?php endif; ?>
                    }
                    else
                    {
                        $("#loader-sub-menu").html('');
						$('#message').html(result.msg);
                        $('#enregistrer').prop("disabled", true);
                        $("#delete").prop("disabled", true);
                    }

                    comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');

                '<?php else: ?>'
                    // When it's the operator
                    if (result.code === "E411") {
                        $('#message').html('');
                        $('#message').html('<div class="alert aDanger text-white"> Un probl&egrave;me est survenu, veuillez refaire le paiement s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#enregistrer').prop("disabled", false);
                    } else if (result.code === "E412") {
                        $('#message').html('');
                        $('#message').html('<div class="alert aDanger text-white"> Ce paiement a un probl&egrave;me, veuillez conctater votre administrateur !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#enregistrer').prop("disabled", false);
                    }
                    else if(result.code === "E305")
                    {
                        $('#message').html('<div class="alert aDanger text-white">Paiement non enregistr&eacute;. Un probl&egrave;me est survenu, veuillez refaire s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        $('#enregistrer').prop("disabled", false);
                    }
                    else {
                        $('#step2').remove;
                        $("#step-2").removeClass('bg-green-active');
                        $("#step-2").addClass('bg-gray');
                        $("#step-3").removeClass('bg-gray');
                        $("#step-3").addClass('bg-green-active');

                        $('#enregistrer').prop("disabled", false);

                        var url = '<?php echo base_url($module . '/taxnotes/display/preview'); ?>/' + result.id;
                        $.get(url, function(data, status) {
                            $('#message').html('<div class="alert aSuccess text-white">Bravo! paiement encaiss&eacute; avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            $("#pager").html(data);
                        })
                    }

                '<?php endif; ?>'
            },
            error: function(error) {
                $('#enregistrer').prop("disabled", false);
                $('#message').html('<div class="alert aDanger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse du core banking est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans le core banking !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    }

    $("#closePanel").click(function() {

        if(controller)
        {
            closeView(controller, from);
        }
        else
        {
            location.reload();
        }

    });
    
    $("#btn-reject").click(function(event){
    
        var motif = $("#motif").val();
        $("#rejected").val(motif);
        var reject_data = $("#form").serialize();
        
        if(motif !="")
        {   
                event.preventDefault();
               
                $('#message').html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                scrollUP(); 
                var message = '<div class="alert alert-success text-white">Bravo! paiement rejet&eacute;  avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
                var url = '<?php echo base_url($module.'/taxnotes/save/rbo_reverse'); ?>';
        //                var data = $("#form").serialize();
                $('#prompt_model').modal('hide'); 
                
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : reject_data, 
                        dataType    : 'html', 
                        encode          : true,
                        success: function(result){
                                $('#message').html('');
                                
                                if(result === "E300")
                                {
                                        $("#message").html('');
                                        $('#message').html('<div class="alert alert-danger text-white">L\'envoi des &eacute;critures &agrave; amplitude fait avec succ&egrave;s, sauf que les &eacute;critures ne sont pas int&eacute;gr&eacute;es ou sont int&eacute;gr&eacutes partiellement d&ucirc; &agrave; un probl&eacute;me du d&eacute;saccord commercial ou administratif ou du chapitre d\'un compte. Allez dans le menu regularisation pour regulariser ce paiement. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else if(result === "E404")
                                {
                                        $("#message").html('');
                                        $('#message').html('<div class="alert alert-danger text-white">L\'envoi des &eacute;critures &agrave; amplitude fait avec succ&egrave;s, sauf que les &eacute;critures ne sont pas int&eacute;gr&eacute;es ou sont int&eacute;gr&eacutes partiellement d&ucirc; au probl&eacute;me de compte fermé, chapitre non autorisé ou sens du compte incorrect. Allez dans le menu regularisation pour regulariser ce paiement!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else if(result === "E411")
                                {
                                        $("#message").html('');
                                        $('#message').html('<div class="alert alert-danger text-white"> L\'envoi des &eacute;critures &agrave; amplitude fait avec succ&egrave;s. Mais amplitude a retourn&eacute; une r&eacute;ponse partielle par rapport au lot des &eacute;critures envoy&eacute;es. Allez dans le menu regularisation pour continuer l&apos;op&eacute;ration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else if(result === "E405")
                                {
                                        $("#message").html('');
                                        $('#message').html('<div class="alert alert-warning text-white">Aucune &eacute;criture envoy&eacute;e &agrave; amplitude pour ce paiement d&ucirc; au probl&egrave;me d\'informations manquantes.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else if(result === "E412")
                                {
                                        $("#message").html('');
                                        $('#message').html('<div class="alert alert-danger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse amplitude est d&eacute;pass&eacute;. Allez dans le menu regularisation pour extourner les fonds!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                }
                                else
                                {
                                        $('#message').html(message);
                                        $("#reject").prop('disabled', true);
                                }
                        },
                        error:function(error)
                        {
                            $('#message').html('<div class="alert alert-danger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse amplitude est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans amplitude !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                });
        }
        else
        {
                $('#message').html('<div class="alert alert-danger text-white"> Desol&eacute; ... le champ motif ne peut &ecirc;tre vide !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    
    });

    function closeView(controller, display) {
        if (controller != '' && display != '') {
            $.get("<?php echo base_url($module . '/' . $controller . '/display/' . $from); ?>", function(data, status) {
                $('#message').html('');
                $("#container").html(data);
            });
        } else {
            <?php if ($_SESSION['Logiref_role'] == 4) { ?>

                close_form();

            <?php } else { ?>

                location.reload();

            <?php } ?>
        }
    }

    function close_form() {
        $.get("<?php echo base_url($module . '/taxreports/display/' . $previous_menu); ?>", function(data, status) {
            $('#message').html('');
            $("#pager").html(data);
            $("#pager").addClass('content');

            $("#close").removeClass('hidden');
            $("#close_form").addClass('hidden');

        });
    }
    
    function scrollUP(){
        $('html, body').animate({
            scrollTop: $("#message").offset().top
        }, 20);
    }
    
    function verify_iprier_amount()
    {
        if($('#dgi_unique').is(":checked"))
        {
            var montant_paye = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));
            var dgi = parseFloat($("#quota_dgi_unique").val().split(' ').join('').split(',').join('.'));
            
            montant = dgi;
            montant = Math.round(montant*100)/100; 
            
            if(montant_paye > montant || montant_paye != montant)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        else
        {
            var montant_paye = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));

            var dgi = parseFloat($("#quota_dgi").val().split(' ').join('').split(',').join('.'));
            var onem = parseFloat($("#quota_onem").val().split(' ').join('').split(',').join('.'));
            var inss = parseFloat($("#quota_inss").val().split(' ').join('').split(',').join('.'));
            var inpp = parseFloat($("#quota_inpp").val().split(' ').join('').split(',').join('.'));
            var montant = "";

            montant = dgi + onem + inss + inpp;

            montant = Math.round(montant*100)/100; 

            if(montant_paye > montant || montant_paye != montant)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }

</script>

<!-------------------------  Section propres a Step 3  ------------------------------>
<script type="text/javascript" charset="utf-8">

    $("#pager").on("click", "#print", function() {
        var param = null;
        // Désactiver les boutons si l'option existe
        <?php if(isset($options['ALL']['bank-charges-attestation-printing'])): ?>
            $("#print").prop("disabled", true);
            $("#print_attestation").prop("disabled", true);

            var printdup = $("#print_duplicata").val();

            if (printdup == "FDA") {
                param = "DUP";
            }
        <?php endif; ?>

        $("#enregistrer").prop("disabled", true);

        var id = ref;
        var base = '<?php echo base_url($module . "/taximpression/display/attestation"); ?>';

        // Vérifier si param n'est pas null
        var url = (param !== null) ? base + '/' + ref + '/' + param : base + '/' + ref;

        var w = window.open(url, "_blank");

        if (w) {
            // Vérifier que la fenêtre s'est bien ouverte
            $(w).on("load", function () {
                try {
                    // Lancer l'impression automatiquement
                    w.print();

                    $('#message').html('<div class="alert aSuccess text-white">Bravo! Attestation générée et impression lancée...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#print").prop("disabled", true);
                    $("#print_attestation").prop("disabled", true);

                } catch (e) {
                    // Si une erreur survient, on réactive le bouton
                    $("#print").prop("disabled", false);

                    $('#message').html('<div class="alert aDanger text-white"> Error : Erreur lors de la génération du PDF. Veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });

            // Gestion du cas où la fenêtre est fermée trop tôt
            var checkClosed = setInterval(function () {
                if (w.closed) {
                    clearInterval(checkClosed);
                    $("#print").prop("disabled", false);
                }
            }, 1000);

        } else {
            // Si le popup a été bloqué
            $("#print").prop("disabled", false);
            $("#enregistrer").prop("disabled", false);
            
            $('#message').html('<div class="alert aWarning text-white"> Information : Le navigateur a bloqué la génération de l’attestation.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
        }
    });

    $("#schema").click(function() {

        var id = ref;
        var url = '<?php echo base_url($module . '/taximpression/display/schema'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function() {
            w.print();
        });
    });

    $("#delete").click(function() {
       var recette = '<?php echo $encaissement->Typerecette_17; ?>';
        var reference = '<?php echo $encaissement->Logirefid_4; ?>';

        swal({
                title: "SUPPRESSION",
                text: "Etes-vous sûr de vouloir supprimer cette ligne ?",
                type: "warning",
                showCancelButton: true,
                cancelButtonText:"Non",
                confirmButtonText: "Oui",
                closeOnConfirm: true,
                confirmButtonColor: "#c9302c"
            },function(isConfirm){
                if(isConfirm) {
                    var url = '<?php echo base_url($module . '/taxnotes/save/delete'); ?>/' + reference + '/' + recette;
                    scrollUP();
                    $.ajax({
                        type: 'GET',
                        url: url,
                        dataType: 'html',
                        encode: true,
                        success: function(result) {
                            $('#loader-sub-menu').html('');
                            $('#loader-sub-menu').html(result);

                            $('#enregistrer').prop("disabled",true);
                            $('#save').prop("disabled",true);
                            $('#delete').prop("disabled",true);
                        },
                        error: function(error) {
                            $('#loader-sub-menu').html('<div class="alert alert-danger text-white">ERREUR : La supression n\'a pas r&eacute;ussi, un probl&egrave;me est survenu.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                    });
                }
            });
    });

    <?php if (isset($encaissement->Id_0) && $encaissement->Id_0 != '' && $encaissement->Id_0 != 0) { ?>
            var mode = $('#modeId').val();
            if (mode === '7' || mode == '8') {
                    $("#compteId").prop('disabled', '');
                    $("#compteDevise").prop('disabled', '');
            }
            comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');
    <?php } ?>


    function comptabilisation(ref) {
        
        $('#loader_scheme').html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');

        var url = '<?php echo base_url($module . '/taxcomptabilisation/display/get_details_dgrad'); ?>/' + ref;
        $.get(url, function(data, status) {
            $('#loader_scheme').html('');
            $("#Comptabilisation").html(data);
        });
    }
    
    function format_amount(amount)
    {
            amount = amount.replace(/ /g,"");
            amount = amount.replace(/\B(?=(\d{3})+(?!\d))/g, " ");

            return amount;
    }

    function handle_exchange_rate(param) 
    {
        const taux_initial = <?= $taux['Dollar_4']; ?>;

        // Nettoyage et parsing du montant
        let montant_note = parseFloat($('#montantNote').val().replace(/\s/g, '').replace(',', '.')) || 0;
        const devise_note = $('#deviseNote').val();
        const devise_compte = $('#compteDevise').val();

        // Conversion si devise est CDF
        if (devise_note === 'CDF') {
            montant_note = montant_note / taux_initial;
        }

        console.log('Montant de la note après conversion en USD: ' + montant_note);

        $("#Tauxflag_58").remove();

        const seuil = 5001;
        const condition_taux = montant_note >= seuil &&
            ((devise_compte === 'USD' && devise_note === 'CDF') || (devise_note === 'USD' && devise_compte === 'CDF'));

        if (condition_taux) {
            $('#loader').html(`
                <div class="alert alert-info text-black">
                    Le montant de cette opération dépasse 5 000 $. 
                    Veuillez renseigner un taux de change validé par votre superviseur avant de continuer.
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                </div>
            `);

            $("#Taux").prop("required", true);

            if (param) {
                const taux_modif = parseFloat($('#Taux').val().replace(/[\s,]/g, '.')) || taux_initial;
                $("#Taux").val(taux_modif === taux_initial ? '' : taux_modif);
            }

            if (!$("#Tauxflag_58").length) {
                set_taux_flag(1);
            }
        } else {
            $('#loader, #loader2, #loader3').html('');
            $("#Taux").prop("required", false).val(taux_initial);
            set_taux_flag(0);
        }
    }

    function update_montant_total_final() 
    {
        get_account_exemption(function(reponse) {
            // Ici on est sûr que #commission et #commissionAttestation sont mis à jour
            compute_montant_total();
        });
    }

    function compute_montant_total() 
    {
        let taux = parseFloat($('#Taux').val().replace(/\s+/g, '').replace(',', '.')) || <?= $taux['Dollar_4']; ?>;
        let montant_initial = parseFloat($('#recetteMontant').val().replace(/\s/g, '')) || 0;
        let montant = montant_initial;
        let commission = parseFloat($('#commission').val().replace(/\s/g, '')) || 0;
        let commissionAttestation = parseFloat($('#commissionAttestation').val().replace(/\s/g, '')) || 0;

        const deviseMontant = $('#recetteDevise').val();
        const deviseCommission = $('#commissionDevise').val();

        const tva = (commission * 16) / 100;
        const tvaAttestation = (commissionAttestation * 16) / 100;

        let fraisBCC = (montant_initial * 0.5) / 1000;
        if (deviseMontant == 'USD') {
            fraisBCC = fraisBCC / taux;
        }

        const montantTotal = montant + commission + commissionAttestation + fraisBCC + tva + tvaAttestation;
        const montantTotalFormatted = montantTotal.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");

        $('#montantTotal').val(montantTotalFormatted);
        $('#totalDevise').val(deviseMontant);
    }

    function set_taux_flag(value) 
    {
        const $flag = $("#Tauxflag_58");

        if ($flag.length) {
            $flag.val(value);
        } else {
            $('<input>', {
                type: 'hidden',
                id: 'Tauxflag_58',
                name: 'Tauxflag_58',
                value: value
            }).appendTo('form');
        }
    }

</script>