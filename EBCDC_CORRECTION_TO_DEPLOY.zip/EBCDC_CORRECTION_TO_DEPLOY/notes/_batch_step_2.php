
<div id="message"></div>
<div id="loader"><?php echo ""; ?></div>
<?php echo form_open('', array('id' => 'main_form', 'class' => '')); ?> 
<style>.input-no-border {border-top: 0 !important; border-left: 0 !important; border-right: 0 !important; background:none !important; padding-left: 0 !important; }</style>
<?php $chtml->box_body_opening('', true); ?>
    <div class="col-md-12">
        <?php $com = str_replace(' ','',$commission); $com = str_replace(',','.',$com);
        ?>
        <input type="hidden" name="Taux" value="<?= $taux ?? "" ?>" />
        <input type="hidden" name="RefOp" value="<?= $refOp ?? ""; ?>" id="refOp" />
        <input type="hidden" name="Notedate" value="<?= $notedate ?? ""; ?>" />
        <input type="hidden" name="PaidATTESTATION" value="<?= $paid_attestation ?? ""; ?>" />
        <input type="hidden" name="Beneficaire" value="<?= $regie ?? ""; ?>" />
        <input type="hidden" name="Commission" value="<?= $commission ?? 0; ?>" />
        <input type="hidden" name="Commission_lot" value="<?= $commission_lot ?? 0; ?>" />
        <input type="hidden" name="Com_attestation" value="<?= $com_attestation ?? 0; ?>" />
        <input type="hidden" name="Tauxflag" value="<?= $tauxflag ?? 0; ?>" />
        <input type="hidden" name="Logirefid" value="" id="batch_id" />

        <div class="col-md-12 p-0">
            <div class="row">
                <div class="col-md-12 p-0">
                    <h2 class=" f20 w-300 page-header">Traitement des notes  en lot</h2>
                    <br/>
                </div>
                <div class="col-12">
                    <div class="col-12">
                        <br><br>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row">
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Service recouvrement</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?=  $services["DGRAD"][$service] ?? ""; ?>
                                                <input type="hidden" name="Service" value="<?=  $service ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Numéro impôt</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $nif ?? ""; ?>
                                                <input type="hidden" name="Nif" value="<?= $nif ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Désignation</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $designation ?? ""; ?>
                                                <input type="hidden" name="Designation" value="<?= $designation ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">intitulé du compte</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?=  $accountname ?? ""; ?>
                                                <input type="hidden" name="Account_name" value="<?=  $accountname ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Compte du client</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b>  <?= $account; ?>
                                                <input type="hidden" name="Compte" value="<?= $account ?? ""; ?>" id="" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Devise du compte</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?=  $acurrency ?? ""; ?>
                                                <input type="hidden" name="Devise_compte" value="<?= $acurrency ?? ""; ?>" id="" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Mode de paiement</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $modes[$mode] ?? "" ?>
                                                <input type="hidden" name="Mode" value="<?= $mode ?? "" ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Montant total du lot</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= number_format(($montant_note ?? 0),2,","," "). " ".$devise_note; ?>
                                                <input type="hidden" name="Montant_note" value="<?= $montant_note ?? 0; ?>" />
                                                <input type="hidden" name="Devise_note" value="<?= $devise_note ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Total Commission</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= number_format(($total_com ?? 0),2,","," "). ' ' .$com_currency; ?>
                                                <input type="hidden" name="Total_com" value="<?= $total_com ?? 0; ?>" />
                                                <input type="hidden" name="Devise_com" value="<?= $com_currency ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Total TVA</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= number_format((($total_com * 0.16) ?? 0),2,","," "). " " .$com_currency; ?>
                                                <input type="hidden" name="Tva" value="<?= ($total_com * 0.16) ?? 0 ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Total à payer</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b>  <?= number_format(($total_to_paid ?? 0),2,","," ")." ". $totalpaid_currency; ?>
                                                <input type="hidden" name="Total_topaid" value="<?= $total_to_paid ?? 0; ?>" id="total_topaid" />
                                                <input type="hidden" name="Devise_totalpaid" value="<?= $totalpaid_currency ?? ""; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row"> 
                                        <div class="input-group col-md-12">
                                            <div class="col-md-4">
                                                <label for="office" class="f12 text-black">Nombre de notes</label>
                                            </div>
                                            <div class="col-md-8 f12 text-black">
                                                <b>:</b> <?= $total_lines ; ?>
                                                <input type="hidden" name="Total_line" value="<?= $total_lines ?? 0; ?>" />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="footpage" class="clearfix"></div>
                <div class="col-12 border-bottom">
                    <br><br>
                </div>
            </div>
        </div>

        <div class="p-0 border-top">
            <div class="box-body" id="box_body">
                <?php if (!empty($notes)) : ?>
                    <table id="notesTable" class="table table-striped table-hover">
                        <thead class="bg-gray">
                            <tr>
                                <th width="10px">#</th>
                                <th width="500px">Nature</th>
                                <th width="150px">Référence</th>
                                <th width="80px">Devise</th>
                                <th width="150">Montant</th>
                                <th class="text-center">Retour Logirad</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; foreach ($notes as $line): ?>
                                <tr id="line<?= $i; ?>">
                                    <td><span class="text-gray"><b><?= $i; ?></b></span></td>
                                    <td>
                                        <?php echo form_dropdown('recettes['.$i.']', $recettes, $line["recette"], 'class="form-control input-no-border" '); ?>
                                    </td>
                                    <td>
                                        <input id="reference<?= $i; ?>" type="text" 
                                            value="<?= htmlspecialchars($line["numero"]); ?>" 
                                            name="references[<?= $i; ?>]" 
                                            class="form-control input-no-border" />
                                    </td>
                                    <td>
                                        <input id="devise<?= $i; ?>" type="text" 
                                            value="<?= htmlspecialchars($line["devise"]); ?>"  
                                            name="devises[<?= $i; ?>]"   
                                            class="form-control  input-no-border" />
                                    </td>
                                    <td>
                                        <input id="amount<?= $i; ?>" type="text" 
                                            value="<?= number_format($line["montant"], 2, ",", " "); ?>" 
                                            name="amounts[<?= $i; ?>]" 
                                            class="form-control input-no-border" />
                                    </td>
                                    <td class="text-center">
                                        <?php if ($line['api_code'] === "API_UNAVAILABLE"): ?>
                                            <span id="logirad_result<?= $i; ?>" class="badge badge-danger">
                                                La vérification est momentanément impossible.
                                            </span>
                                        <?php elseif ($line['status'] === "error"): ?>
                                            <span class="badge badge-warning">
                                                Erreur (<?= $line['api_code'] ?? ""; ?>)
                                            </span>
                                        <?php elseif ($line['status'] === "OK"): ?>
                                            <span class="badge badge-success">
                                                Validé
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">
                                                À vérifier
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php $i++; endforeach; ?>
                        </tbody>
                    </table>

                    <!-- conteneur caché pour inputs clonés --> 
                    <div id="hiddenInputs" style="display:none;"></div>
                <?php else : ?>
                    <section>
                        <div class="row fontawesome-icon-list f14 text-center" style="min-height: 50vh; padding-top: 20%;">
                            <i class="fa fa-fw fa-warning text-gray mystyle4 fa-3x"></i><br />
                            <h4 class="text-center mt-3">
                                <b>Aucune note disponible pour le moment.</b>
                            </h4>
                            <p class="text-muted">Veuillez vérifier vos données ou importer un fichier contenant des notes valides.</p>
                        </div>
                    </section>
                <?php endif; ?>
            </div>

            <div id="box_schema" class="d-none">
                <!------------------------- Repartitions  ------------------------------>
                <div class="row>">
                    <div class="col-md-12"><br /><label>Sch&eacute;ma de comptabilisation </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
                </div>
                <div class="row"><div class="col-md-12" id="loader_scheme"></div></div>
                <div class="row">
                    <div id="Comptabilisation" class="col-md-12"></div>
                </div>
                <!-------------------------  END  ------------------------------>
            </div>

            <div  class="box-footer clearfix">
                <div class="row">
                    <div id="createPaiement" class="col-md-12">
                        <button type="submit" id='save' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="print" disabled="disabled" class="btn btn-primary d-none"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="schema" disabled="disabled"   class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le sch&eacute;ma comptable &nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="cancel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $chtml->box_body_closing(); ?>

<?php echo form_close(); ?>

<script type="text/javascript"  charset="utf-8">

    $(".select2").select2();
    $(document).ready(function() {
        $('#notesTable').DataTable({
            paging: true,
            pageLength: 5, 
            lengthChange: false,
            searching: false,
            ordering: true,
            info: true,
            autoWidth: false
        });
    });

    $('#main_form').submit(function(event) {
        event.preventDefault();

        $("#loader").html('<img align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif') ?>" />');
        scrollUP();

        let table = $('#notesTable').DataTable();

        // Vider le conteneur caché avant chaque submit 
        $('#hiddenInputs').empty();

        // Cloner les inputs des pages non visibles
        table.$('input, select, textarea').each(function() {
            if (!$.contains(document, this)) {
                $(this).clone().appendTo('#hiddenInputs');
            }
        });

        let data = $(this).serialize();
        let url = '<?php echo base_url($module . '/taxnotes/save/save_batch'); ?>';

        $('#save').prop("disabled", true);

        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'json',
            encode: true,
            success: function(response) {
                if (response.code == 200) {
                    $("#loader").html('<div class="alert aSuccess text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#step-2").removeClass('bg-green-active').addClass('bg-gray');
                    $("#step-3").removeClass('bg-gray').addClass('bg-green-active');
                    $("#schema").prop("disabled", false);

                    $("#batch_id").val(response.id);

                    $("#box_body").addClass('d-none');
                    $("#box_schema").removeClass('d-none');

                    comptabilisation(response.id);

                } else if (response.code == 401) {
                    $("#loader").html('<div class="alert aDanger text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $('#save').prop("disabled", false);
                } else if (response.code == 402 || response.code == 403 || response.code == 405) {
                    $("#loader").html('<div class="alert aDanger text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else if (response.code == 500) {
                    $("#loader").html('<div class="alert alert-info text-white">'+ response.message + '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                } else {
                    $("#loader").html('<div class="alert aDanger text-white">Une erreur inattendue est survenue<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            },
            error: function(xhr, status, error) {
                $("#loader").html('<div class="alert aDanger text-white">Erreur technique lors de l\'enregistrement. Veuillez réessayer plus tard<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    $("#schema").click(function(){
                    
        let ref = $("#batch_id").val();
        let url = '<?php echo base_url($module.'/taximpression/display/schema_batch'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        let w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
    });

    $("#cancel").click(function(){
        location.reload(true);
    });

    function comptabilisation(logirefid)
    {
        $('#loader_scheme').html('<img align="middle" height="15px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');

        let url = '<?php echo base_url($module.'/taxcomptabilisation/display/get_details_dgrad'); ?>/' + logirefid;
        $.get(url, function(data, status){
            $('#loader_scheme').html('');
            $("#Comptabilisation").html(data);
        });
    }

    function scrollUP() 
    {
        $('html, body').animate({
            scrollTop: $("#loader").offset()
        }, 20);
    }


</script>