<?php $userid = $_SESSION["userdata"]["user_id"]; $feuille=''; $Infos = (isset($encaissement->Notereference_30))?json_decode($encaissement->Notereference_30, true):""; $disabled = "disabled"; ?>

<?php //if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; }else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if(isset($encaissement->Montant_11) && $encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if(isset($encaissement->Notemontant_28) && $encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && isset($encaissement->Id_0) && $encaissement->Makerid_9==$userid && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>

<?php if(isset($_POST['Noteid_26']) && $_POST['Noteid_26'] !='') {$reference = $_POST['Noteid_26'];}elseif(isset($content['Reference_32']) && $content['Reference_32'] !=""){$reference = $content['Reference_32'];}else{ $reference = "";}?>
<?php
    if(isset($_SESSION['Bank_rates'])):
        $taux = json_decode($_SESSION['Bank_rates'], true);
    else:
        $taux['Dollar_4']  = 00;
        $taux['Euro_5']  = 00;
        $taux['Rand_6']  = 00;
    endif;

    if(!isset($infos['totalMontant']))
    {
            $infos['totalMontant'] = '';
            $infos['totalDevise'] = isset($encaissement->Devise_12)?$encaissement->Devise_12:"";

            $valeur01 = $devise01 = $mode = $devise_montant = '';
            $infos['RefINSS'] = $infos['RefINPP'] = $infos['RefONEM'] = $infos['QuotasINSS'] = $infos['QuotasINPP'] = $infos['QuotasONEM'] = '';
            $infos['standard'] = '';
    }
?>


<?php echo form_open('', array('id' => 'form', 'class' => '')); ?>
    <style>label {min-width: 150px !important;}</style>
    <?php $chtml->box_body_opening('', true);?>
    <input type="hidden" name="Id_0" value="<?= isset($encaissement->Id_0)?$encaissement->Id_0:""; ?>" />
    <input type="hidden" name="Ndeclaration" value="<?= isset($declaration->Id_0) ? $declaration->Id_0 : 1; ?>" />
    <input type="hidden" name="Account_3" value="<?= isset($encaissement->Account_3)?$encaissement->Account_3:""; ?>" />
    <input type="hidden" name="Logirefid_4" value="<?= $reference; ?>" />
    <input type="hidden" name="Banqueid_5" value="<?= isset($encaissement->Banqueid_5)?$encaissement->Banqueid_5:""; ?>" />
    <input type="hidden" name="Isysid_7" value="<?= isset($encaissement->Isysid_7)?$encaissement->Isysid_7:""; ?>" />
    <input type="hidden" name="Rtgsid_8" value="<?= isset($encaissement->Rtgsid_8)?$encaissement->Rtgsid_8:""; ?>" />
    <input type="hidden" name="Artbudgetaire_18" value="<?= isset($encaissement->Artbudgetaire_18)?$encaissement->Artbudgetaire_18:""; ?>" />
    <input type="hidden" name="Agence_20" value="<?= $_SESSION['Logiref_agence']; ?>" />
    <input type="hidden" name="Guichet_21" value="<?= $_SESSION['Logiref_guichet']; ?>" id="guichetId" />
    <input type="hidden" name="Changement_35" value="<?= isset($encaissement->Changement_35)?$encaissement->Changement_35:""; ?>" />
    <input type="hidden" name="Validation_36" value="<?= isset($encaissement->Validation_36)?$encaissement->Validation_36:""; ?>" />
    <input type="hidden" name="Integration_37" value="<?= isset($encaissement->Integration_37)?$encaissement->Integration_37:""; ?>" />
    <input type="hidden" name="Reversement_38" value="<?= isset($encaissement->Reversement_38)?$encaissement->Reversement_38:""; ?>" />
    <input type="hidden" name="Nivellement_39" value="<?= isset($encaissement->Nivellement_39)?$encaissement->Nivellement_39:""; ?>" />
    <input type="hidden" name="Suppression_40" value="<?= isset($encaissement->Suppression_40)?$encaissement->Suppression_40:""; ?>" />
    <input type="hidden" name="Sydonia_44" value="<?= isset($encaissement->Sydonia_44)?$encaissement->Sydonia_44:""; ?>" />
    <input type="hidden" name="Tresor_45" value="<?= isset($encaissement->Tresor_45)?$encaissement->Tresor_45:""; ?>" />
    <input type="hidden" name="Missmatch_46" value="<?= isset($encaissement->Missmatch_46)?$encaissement->Missmatch_46:""; ?>" />
    <input type="hidden" name="Isyserrors_47" value="<?= isset($encaissement->Isyserrors_47)?$encaissement->Isyserrors_47:""; ?>" />
    <input type="hidden" name="Sydonia_49" value="<?= isset($encaissement->Sydonia_49)?$encaissement->Sydonia_49:""; ?>" />
    <input type="hidden" name="Beneficaire_15" value="DGRK"  id="regies" />

    <div class="box-body">
            <div class="row">
                <div class="col-md-12">
                    <h2 class=" f20 w-300 page-header text-black"><b>Veuillez renseigner toutes les informations requises</b></h2>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12" id="loader-sub-menu"><?php if(!empty($note_reference)) echo '<div class="alert alert-danger text-white"> La d&eacute;claration avec la r&eacute;f&eacute;rence '.$note_reference->Noteid_26.' a d&eacute;j&agrave; &eacute;t&eacute; pay&eacute;e !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>'; ?></div>
            </div>

            <!------------------------- Beneficiare  ------------------------------>
            <div class="row">
                <div class="col-md-12"><br/><span class="f12 text-black"><b><label>Partie 1 : R&eacute;gies financi&egrave;re</label></b></span></div>
            </div>
            <div class="row">
                <div class="col-md-5 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Beneficaire_15" class="f12">B&eacute;n&eacute;ficiare</label>
                        </span>
                        <?php echo form_dropdown('Beneficaire_15', array('DGRK' => 'DGRK'), 'DGRK', ' class="form-control bg-gray" id="regie" required="required"  '); ?>
                        <?php if($encaissement->Id_0 !=NULL): ?>
                            <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="input-group"  id="regie0">
                        <span class="input-group-addon">
                            <label for="Service_16"  class="f12"><div id="ServiceId">Service recouvrement</div></label>
                        </span>
                        <div class="overflow-hidden flex-grow-1">
                            <span id="slist"><?php echo form_dropdown('Service_16', $services, isset($content['Service']) ? $content['Service'] : "" , 'class="form-control select2" id="service"  required="required" '); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-------------------------  Titre de perception  ------------------------------>
            <div class="row">
                <div class="col-md-12"><br/><span class="f12 text-black"><b><label>Partie 2 : Titre de paiement</label></b></span></div>
            </div>
            <div class="row">
                <div class="col-md-5 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Noteid_26" class="f12"><div id="TitreId">Num&eacute;ro</div></label>
                        </span>
                        <?php echo form_input('Noteid_26', set_value('Noteid_26', $reference), ' class="form-control" id="reftitre" maxlength="25"'); ?>
                    </div>
                </div>
                <div class="col-md-7 small-box">
                <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Notetype_25" class="f12">Document</label>
                        </span>
                        <?php echo form_input('Notetype_25', set_value('Notetype_25', $documents[5]), 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                        <input type="hidden" name="Notetype_25" value="5">
                    </div>
                </div>
                <div id="bl" class="col-md-12"></div>
                <div class="col-md-5 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Notedate_27" class="f12">Date &eacute;mission</label>
                        </span>
                        <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                </div>
                <div class="col-md-7 small-box">
                    <div class="input-group"  id="recette0">
                        <span class="input-group-addon">
                            <label for="Typerecette_17" class="f12">Nature paiement</label>
                        </span>
                        <?php echo form_dropdown('Typerecette_17', $recettes, '', 'class="form-control select2" id="recette" required="required" '); ?>
                    </div>
                </div>

                <div class="col-md-5 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="standard" class="f12">P&eacute;riode</label>
                        </span>
                        <?php echo form_input("Infos[standard]", set_value("Infos[standard]", ''), ' class="form-control" id="datepicker3" maxlength="25"'); ?>
                    </div>
                </div>
                <div class="col-md-5 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Notemontant_28" class="f12">Montant de la note</label>
                        </span>
                        <?php echo form_input('Notemontant_28', set_value('total', isset($paiement['Notemontant']) ? $paiement['Notemontant'] : ""), ' id="montantNote" class="form-control" required="required"'); ?>
                    </div>
                </div>
                <div class="col-md-2 small-box">
                    <div>
                        <!--<span class="input-group-addon" style="padding-left:0px !important"></span>-->
                        <?php echo form_dropdown('Notedevise_29',$devises, '', 'class="form-control" id="deviseNote"  required="required"'); ?>
                    </div>
                </div>
            </div>

            <!------------------------- Payement  ------------------------------>
            <div class="row">
                <div class="col-md-5"><br /><span class="f12 text-black"><b>Partie 3 : Assujetti ou Contribuable.</b></span></div>
                <?php if(isset($options['ALL']['auto-fetch-client-accounts'])): ?>
                    <div class="col-md-5" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br /><span id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span  id="accountname"></span></span></div>
                    <div class="col-md-2" id=""><span id="" class="text-red" style="padding-left:0px; "></span><br /><span id="" style=""><span  id="labelNumber"></span></span></div>
                <?php else: ?>
                    <div class="col-md-7" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br /><span id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span  id="accountname"></span></span></div>
                <?php endif; ?>

                <input type="hidden" name="Infos[fraisbcc]"  value="1" id="infosFbcc">
                <input type="hidden" name="Infos[tva]" value="1" id="infosTva">
            </div>

            <div class="col-md-12 d-none" id="exchange_bloc"><b>R&eacute;cup&eacute;ration du taux d'echange : </b> <span id="exchange_message"></span></div>

            <div class="row">
                <div class="col-md-5 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Nif_13" class="f12">Num&edot;ro imp&ocirc;t</label>
                        </span>
                        <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control" required="required" maxlength="86"'); ?>
                    </div>
                </div>
                <div class="col-md-7 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Designation_14" class="f12">D&eacute;signation</label>
                        </span>
                        <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86"'); ?>
                    </div>
                </div>
                <div class="col-md-5 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Mode_19" class="f12">Mode de paiement</label>
                        </span>
                        <?php echo form_dropdown('Mode_19', $modes, $mode, 'class="form-control" required="required" id="modeId"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Taux_41" class="f12">Taux de change</label>
                        </span>
                        <?php echo form_input('Taux_41', ($encaissement->Taux_41 !="") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
                        <input type="hidden" value="TTB" name="Infos[rate_code]" id="rate_code" >
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                        <label for="Datevaleur_31" class="f12">Date paiement</label>
                        </span>
                        <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  disabled="disabled" required="required" '); ?>
                        <input type="hidden" name="Datevaleur_31" value="<?= gmdate('Y-m-d')?>" id="">
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Reference_32" class="f12">R&eacute;f&eacute;rence de l&apos;OP</label>
                        </span>
                        <?php echo form_input('Reference_32', set_value('Reference_32', $reference), 'class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-5 small-box">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Compte_33" class="f12"><div id="compteLabel">Compte du client</div></label>
                        </span>
                        <?php echo form_input('Compte_33', set_value('Compte_33',  "" ), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                        <input type="hidden" name="Infos[accountname]" value="" id="account_name">
                        <input type="hidden" name="Infos[accounttax]" value="" id="tax_info">
                        <input type="hidden" name="account_currency" disabled="disabled" value="USD" id="account_currency">
                        <input type="hidden" name="account_balance" disabled="disabled" value="10000000" id="account_balance">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Montant_11" class="f12">Montant &agrave; payer</label>
                        </span>
                        <?php echo form_input('Montant_11', set_value('Montant_11', isset($paiement['Notemontant']) ? $paiement['Notemontant'] : ""), 'class="form-control" id="recetteMontant" required="required"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Commission_23" class="f12"><div id="commiision">Commission</div></label>
                        </span>
                        <?php echo form_input('Commission_23', set_value('Commission_23', ""), 'class="form-control" required="required" id="commission"'); ?>

                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Total" class="f12">Montant total</label>
                        </span>
                        <?php echo form_input("Infos[totalMontant]", set_value('Infos[totalMontant]', ''), 'class="form-control bg-gray" id="montantTotal"'); ?>
                    </div>
                </div>
                <div class="col-md-2 small-box">
                    <div>
                        <?php echo form_dropdown('Devise_34', $devises, '', 'class="form-control"  required="required" id="compteDevise" '); ?>
                    </div>
                    <div>
                        <?php echo form_dropdown('Devise_12', $devises, '', 'class="form-control"  required="required" id="recetteDevise"'); ?>
                    </div>
                    <div>
                        <?php echo form_dropdown('Devise_24', array('CDF'=>'CDF'), 'CDF', 'class="form-control"  required="required" id="commissionDevise"'); ?>
                    </div>
                    <div>
                        <?php echo form_dropdown("Infos[totalDevise]", array('CDF'=>'CDF'), 'CDF', 'class="form-control bg-gray" id="totalDevise"'); ?>
                    </div>
                </div>
            </div>
    </div>
    <div  class="box-footer clearfix">
        <div id="createPaiement" class="col-md-12 pl-0">
                <button type="submit" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Enregistrer&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="print" disabled="disabled" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <button type="button" id="cancel" class="btn btn-warning"><i class="fa fa-times"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</button>&nbsp;&nbsp;
        </div>
    </div>
<?php $chtml->box_body_closing(); ?>
<br/><br/>

<?php echo form_close(); ?>

<script type="text/javascript"  charset="utf-8">
    var ref = '<?php echo $encaissement->Id_0;?>';

    $(".select2").select2();

    var taux = '<?= isset($taux['Dollar_4']) ? $taux['Dollar_4'] : ""; ?>';
    //Datepicker
    $('#datepicker1').datepicker({
            todayHighlight: true,
            format: 'yyyy-mm-dd'
    });
    $('#datepicker2').datepicker({
            todayHighlight: true,
        format: 'yyyy-mm-dd'
    });
    $('#datepicker3').datepicker({
            todayHighlight: true,
        format: 'mm/yyyy'
    });

    $('#montantNote').on("keyup", function() {
        this.value = this.value.replace(/ /g,"");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    });


    $('#recetteMontant').on("keyup", function() {
        this.value = this.value.replace(/ /g,"");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    });

    $('#commission').on("keyup", function() {
        this.value = this.value.replace(/ /g,"");
        this.value = this.value.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    });


    $('#montantNote').change(function(){
            var note = $('#montantNote').val();

            var deviseNote = $('#deviseNote option:selected').val();

            $('#montantNote').val(note);
            $('#recetteMontant').val(note);

            if(note !="")
            {

                note = parseFloat($('#montantNote').val().split(' ').join('').split(',').join('.'));

                if(deviseNote == 'USD')
                {
                    note = note * taux;
                    $('#montantTotal').val(note.toLocaleString());
                }
                else
                {
                    $('#montantTotal').val(note.toLocaleString());
                }

                $('#commission').val('');
                commission();
            }
    });

    $('#deviseNote').change(function(){
            var devise = $('#deviseNote option:selected').val();
            var note = $('#montantNote').val();
            $('#recetteDevise').val(devise);
            $('#totalDevise').val('CDF');

            if(devise !="")
            {
                note = parseFloat(note.split(' ').join('').split(',').join('.'));

                if(devise == 'USD')
                {
                    note = note * taux;
                    if(note) $('#montantTotal').val(note.toLocaleString());
                }
                else
                {
                    if(note) $('#montantTotal').val(note.toLocaleString());
                }

                $('#commission').val('');

                commission();
            }

            var devise_recette = $('#deviseNote option:selected').val();
            var devise_compte = $('#compteDevise option:selected').val();

            if(devise_recette == 'USD' && devise_compte == 'CDF')
            {
                get_exchange_rate();
            }
            else
            {
                $('#exchange_bloc').addClass('d-none');
                taux = '<?= isset($taux['Dollar_4']) ? $taux['Dollar_4'] : ""; ?>';
                $('#Taux').val(taux);
            }
    });

    $('#recetteMontant').change(function(){

            var montant = $('#recetteMontant').val();
            var note = $('#montantNote').val();

            var deviseNote = $('#deviseNote option:selected').val();
            var recetteDevise = $('#recetteDevise option:selected').val();
            $('#recetteDevise').val(deviseNote);

            if(montant !="")
            {
                montant = parseFloat(montant.split(' ').join('').split(',').join('.'));

                note = parseFloat(note.split(' ').join('').split(',').join('.'));

                if(montant > note)
                {
                        $('#info').html('Montant; &agrave; payer sup&eacute;rieur au montant de la note!');
                }
                else
                {
                        var commissions = $("#commission").val();

                        if(commissions !='0' && commissions !='')
                        {
                                commissions = parseFloat(commissions.split(' ').join('').split(',').join('.'));

                                if(deviseNote=='USD')
                                {
                                    montant = montant * taux;

                                    montant = commissions + montant + (commissions *0.16);

                                    $('#montantTotal').val(montant.toLocaleString());
                                }
                                else
                                {
                                    montant = commissions + (montant *0.0005) + montant + (commissions *0.16);
                                    $('#montantTotal').val(montant.toLocaleString());
                                }
                        }
                        else
                        {
                                if(recetteDevise == 'USD')
                                {
                                    montant = montant * taux;
                                    $('#montantTotal').val(montant.toLocaleString());
                                }
                                else
                                {
                                    $('#montantTotal').val(montant.toLocaleString());
                                }
                        }

                        $('#info').html('');
                        commission();
                }
            }
    });

    $('#recetteDevise').change(function(){
            commission();
    });

    $('#service').change(function(){
            commission();
            get_account_tariff();
    });

    function commission() 
    {
        $("#Devise_24").prop("selectedIndex", 0);
        var mode = $('#modeId option:selected').val();
        var montant = $('#recetteMontant').val();
        var regie = 'DGRK';
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var commission = $("#commission").val();
        var guichet = $('#guichetId').val();
        var compte = $('#compteId').val();
        var taux = $('#Taux').val();
        var csrf = $('input[name="csrf_name"]').val();
        //$("#enregistrer").prop('disabled', true);

        if (montant !== '' && devise !== '' && service !== '') {
            var url = '<?php echo base_url('admin/fees/display/'); ?>/default<?php echo $encaissement->Id_0 > 0 ? '/'.$encaissement->Id_0 : ''; ?>';

            $.ajax({
                type: 'POST',
                url: url,
                data: {
                    mode: mode,
                    regie: regie,
                    service: service,
                    recette: recette,
                    devise: devise,
                    montant: montant,
                    guichet: guichet,
                    compte : compte,
                    csrf_name:csrf
                },
                dataType: 'html',
                encode: true,
                success: function(reponse) {
                    var result = JSON.parse(reponse);

                    var fees_found = (result[3] === true || result[3] === "true");

                    if(fees_found)
                    {
                            $("#commission_to_retrieve").val(result[0]);
                            result[0] = result[0].toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                            result[2] = result[2].toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
                            $("#commission").val(result[0]);
                            $("#commissionDevise").val(result[1]);

                            update_montant_total_final();

                            $("#loader-sub-menu").html('');
                    }
                    else
                    {
                            if(commission === '0' || commission === '')
                            {
                                    $("#commission").val('0');
                                    $("#commissionDevise").val('CDF');

                                    update_montant_total_final();

                                    $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Les frais bancaires par rapport à ce montant de paiement ne sont pas paramétrés pour cette agence, veuillez contacter votre administrateur s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                    }

                    $("#enregistrer").prop('disabled', false);
                },
                error: function(error) {
                    $('#bl').html('');
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }
    }

    function update_montant_total_final()
    {
        var taux = '<?php echo $taux['Dollar_4']; ?>';

        let montant = parseFloat($('#recetteMontant').val().replace(/\s/g, '')) || 0;
        let commission = parseFloat($('#commission').val().replace(/\s/g, '')) || 0;

        var correspondentFees = 0;
        var deviseCorrespondent = '';

        const deviseMontant = $('#recetteDevise').val();
        const deviseCommission = $('#commissionDevise').val();

        if (deviseMontant === 'USD')
        {
            montant = montant * taux;
        }

        if (deviseCommission === 'USD')
        {
            commission = commission * taux;
        }

        const tva = (commission * 16) / 100;

        let fraisBCC = 0;

        '<?php if(isset($options['ALL']['bcc-fees-deduction'])): ?>'

            '<?php if(isset($options['ALL']['no-deduction-fees-bcc-when-commission-is-null'])): ?>'

                if (commission > 0)
                {
                    fraisBCC = montant * 0.0005;
                }

            '<?php else: ?>'

                    fraisBCC = montant * 0.0005;

            '<?php endif; ?>'

        '<?php endif; ?>'

        const montantTotal = montant + commission + fraisBCC + tva;

        const montantTotalFormatted = montantTotal.toFixed(2).toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");

        $('#montantTotal').val(montantTotalFormatted);
    }

    $('#form').submit(function(event) {
            // stop the form from submitting the normal way and refreshing the page
            event.preventDefault();
            $("#loader-sub-menu").html('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            //$("#enregistrer").prop('disabled', true);
            scrollUP();

            var data = $(this).serialize();
            var devise = $('#deviseNote option:selected').val();
            var compteDevise = $('#compteDevise option:selected').val();
            var commissionDevise = $('#commissionDevise option:selected').val();
            var totalDevise = $('#totalDevise option:selected').val();
            var recetteDevise = $('#recetteDevise option:selected').val();
            var mode = $('#modeId option:selected').val();
            var test_balance = false;

            var compte = $("#compteId").val();

            if(compte.length == 14)
            {
                test_balance = false;
            }
            else
            {
                test_balance = true;
            }

            if(test_balance)
            {
                get_account_balance(data);
            }
            else
            {
                submiter(data);
            }
    });

    $("#compteId").change(function(){

        var compte = $("#compteId").val();
        get_account_tariff();

        if(compte.length == 14)
        {
                get_accountname_internal();
        }
        else
        {
                get_accountname();

        }
    });


    $("#compteDevise").change(function(){
        var compte = $("#compteId").val();

        if(compte.length == 14)
        {
                get_accountname_internal();

        }
        else
        {
                get_accountname();

        }

        var devise_recette = $('#deviseNote option:selected').val();
        var devise_compte = $('#compteDevise option:selected').val();

        if(devise_recette == 'USD' && devise_compte == 'CDF')
        {
            get_exchange_rate();
        }
        else
        {
            $('#exchange_bloc').addClass('d-none');
            $('#Taux').val(taux);
        }
    });

    $("#cancel").click(function(){
            location.reload(true);
    });

    function get_exchange_rate()
    {
            var devise = $('#compteDevise').val();
            var devise_recette = $('#recetteDevise').val();
            var note_number = $('#reftitre').val();
            var csrf = $('input[name="csrf_name"]').val();

            $('#exchange_bloc').removeClass('d-none');

            $("#exchange_message").html('<img  align="middle" style="height:15px;margin-left:-11px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');

            var url = '<?php echo base_url($module.'/taxrates/data/get_taux'); ?>';

            $.ajax({
                            type        : 'POST',
                            url         : url,
                            data        : { devise_compte : devise, devise_recette : devise_recette, note_number :note_number, csrf_name: csrf }, 
                            dataType    : 'json',
                            encode          : true,
                            success: function(reponse)
                            {
                                    if(reponse.code == '200')
                                    {
                                            $("#Taux").val(reponse.rate);
                                            $("#exchange_message").css('color', 'green');
                                            $("#exchange_message").html('Taux de vente r&eacute;cup&eacute;r&eacute; avec succ&egrave;s.');
                                            $('#rate_code').val('TTS');
                                            taux = reponse.rate;
                                            exchange_changes();
                                    }
                                    else if(reponse.code == '0003')
                                    {
                                            $("#exchange_message").css('color', 'red');
                                            $("#exchange_message").html('Probl&egrave;me de connexion &agrave; Finacle, le taux de vente n\'a pas &eacute;t&eacute; r&eacute;cup&eacute;r&eacute;.');
                                    }

                            },
                            error:function(error)
                            {
                                $('#loader-sub-menu').html('<div class="alert alert-warning">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                    });
    }

    function exchange_changes()
    {
        var note = $('#montantNote').val();

        var deviseNote = $('#deviseNote option:selected').val();

        $('#montantNote').val(note);
        $('#recetteMontant').val(note);

        if(note !="")
        {

            note = parseFloat($('#montantNote').val().split(' ').join('').split(',').join('.'));

            if(deviseNote == 'USD')
            {
                note = note * taux;
                $('#montantTotal').val(note.toLocaleString());
            }
            else
            {
                $('#montantTotal').val(note.toLocaleString());
            }

            $('#commission').val('');
            commission();
        }
    }

    function get_accountname()
    {
            var compte = $('#compteId').val();
            var devise = $('#compteDevise option:selected').val();
            var url = '<?php echo base_url($module.'/taxaccounts/data/get_accountname'); ?>';
            var csrf = $('input[name="csrf_name"]').val();

            if(compte !== '' && devise !=='')
            {
                    $("#accountname").html('<img  align="middle" style="height:15px;margin-left:-11px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
                    $.ajax({
                            type        : 'POST',
                            url         : url,
                            data        : { compte : compte, devise : devise, csrf_name: csrf},
                            dataType    : 'json',
                            encode          : true,
                            success: function(reponse)
                            {
                                    if(reponse.code == '404')
                                    {
                                            $("#accountname").css('color', 'red');
                                            $("#accountname").html('Ce compte n&apos;existe pas');
                                    }
                                    else if(reponse.code == '406')
                                    {
                                            $("#accountname").css('color', 'orange');
                                            $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                    }
                                    else if(reponse.code == '405')
                                    {
                                            $("#accountname").css('color', 'orange');
                                            $("#accountname").html('Le format de compte n\'est pas valide');
                                    }
                                    else if(reponse.currency == null && reponse.account_name == null)
                                    {
                                            $("#accountname").css('color', 'red');
                                            $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                            $("#taxinfo").html('');
                                    }
                                    else if(reponse.currency != devise)
                                    {
                                            $("#accountname").css('color', 'red');
                                            $("#accountname").html('Devise du compte incorrecte');
                                            $("#taxinfo").html('');
                                            $('#compteDevise').val('');
                                    }
                                    else
                                    {
                                            if(reponse.tax_info =='200')
                                            {
                                                    $('#tva_value').prop('disabled', true);
                                                    $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                    $('#tva').prop('checked', '');

                                                    var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));

                                                    var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));

                                                    var total = montant + commissions;

                                                    $("#montantTotal").val(total.toLocaleString());
                                            }
                                            else
                                            {
                                                    var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));

                                                    var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));

                                                    var total = montant + (montant *0.0005) + commissions + (commissions *0.16);

                                                    $("#montantTotal").val(total.toLocaleString());

                                                    $('#tva').prop('checked', 'checked');
                                                    $('#tva_value').prop('disabled', false);

                                                    $("#taxinfo").html('');
                                                    $("#tax_info").val('');
                                            }
                                            $("#accountname").css('color', 'green');
                                            $("#accountname").html(reponse.account_name);
                                            $("#account_name").val(reponse.account_name);
                                            $("#account_currency").val(reponse.currency);
                                            $("#account_balance").val(reponse.balance);
                                    }

                            },
                            error:function(error)
                            {
                                $('#loader-sub-menu').html('<div class="alert alert-warning">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                    });
            }
            else
            {
                    $("#accountname").html('');
            }
    }

    function get_accountname_internal()
    {
            var compte = $('#compteId').val();
            var devise = $('#compteDevise option:selected').val();
            var url = '<?php echo base_url($module.'/taxaccounts/data/get_accountname_internal'); ?>';
            var csrf = $('input[name="csrf_name"]').val();

            if(compte !== '' && devise !=='')
            {
                    $("#accountname").html('<img  align="middle" style="height:15px;margin-left:-11px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
                    $.ajax({
                            type        : 'POST',
                            url         : url,
                            data        : { compte : compte, devise : devise, csrf_name: csrf},
                            dataType    : 'json',
                            encode          : true,
                            success: function(reponse)
                            {
                                    if(reponse.code == '404')
                                    {
                                            $("#accountname").css('color', 'red');
                                            $("#accountname").html('Ce compte n&apos;existe pas');
                                    }
                                    else if(reponse.code == '406')
                                    {
                                            $("#accountname").css('color', 'orange');
                                            $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle!');
                                    }
                                    else if(reponse.code == '405')
                                    {
                                            $("#accountname").css('color', 'orange');
                                            $("#accountname").html('Le format de compte n\'est pas valide');
                                    }
                                    else if(reponse.currency == null && reponse.account_name == null)
                                    {
                                            $("#accountname").css('color', 'red');
                                            $("#accountname").html('Probl&egrave;me de connexion &agrave; finacle');
                                            $("#taxinfo").html('');
                                    }
                                    else if(reponse.currency != devise)
                                    {
                                            $("#accountname").css('color', 'red');
                                            $("#accountname").html('Devise du compte incorrecte');
                                            $("#taxinfo").html('');
                                            $('#compteDevise').val('');
                                    }
                                    else
                                    {
                                            if(reponse.tax_info =='200')
                                            {
                                                    $('#tva_value').prop('disabled', true);
                                                    $('#taxinfo').html(' exon&eacute;r&eacute;');
                                                    $('#tva').prop('checked', '');

                                                    var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));

                                                    var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));

                                                    var total = montant + commissions;

                                                    $("#montantTotal").val(total.toLocaleString());
                                            }
                                            else
                                            {
                                                    var montant = parseFloat($('#recetteMontant').val().split(' ').join('').split(',').join('.'));

                                                    var commissions = parseFloat($('#commission').val().split(' ').join('').split(',').join('.'));

                                                    var total = montant + (montant *0.0005) + commissions + (commissions *0.16);

                                                    $("#montantTotal").val(total.toLocaleString());

                                                    $('#tva').prop('checked', 'checked');
                                                    $('#tva_value').prop('disabled', false);

                                                    $("#taxinfo").html('');
                                                    $("#tax_info").val('');
                                            }
                                            $("#accountname").css('color', 'green');
                                            $("#accountname").html(reponse.account_name);
                                            $("#account_name").val(reponse.account_name);
                                            $("#account_currency").val(reponse.currency);
                                            $("#account_balance").val(reponse.currency);
                                    }

                            },
                            error:function(error)
                            {
                                $('#loader-sub-menu').html('<div class="alert alert-warning">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                    });
            }
            else
            {
                    $("#accountname").html('');
            }
    }

    function get_account_balance(data)
    {
        var compte = $('#compteId').val();
        var devise = $('#recetteDevise option:selected').val();
        var montant = $('#recetteMontant').val();
        var commission = $('#commission').val();
        var devise_commission = $('#commissionDevise').val();
        var devise_compte = $('#account_currency').val();
        var balance = $('#account_balance').val();
        var csrf = $('input[name="csrf_name"]').val();

        if (balance == "no-verification-balance")
        {
            submiter(data);
        }
        else
        {
            var url = '<?php echo base_url('branch/taxaccounts/data/get_account_balance'); ?>';

            $.ajax({
                type        : 'POST',
                url         : url,
                data        : { compte : compte, devise : devise, montant : montant, commission : commission, devise_commission : devise_commission, devise_compte : devise_compte, balance : balance, csrf_name:csrf}, 
                dataType    : 'html',
                encode          : true,
                success: function(reponse)
                {
                        if(reponse == '200')
                        {
                            submiter(data);
                        }
                        else if(reponse == '300')
                        {
                            $("#loader-sub-menu").html('<div class="alert aDanger text-white"> Solde du compte insuffisant pour le paiement de cette d&eacute;claration !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(reponse == '405')
                        {
                            $("#loader-sub-menu").html('<div class="alert aDanger text-white">Veuillez renseigner toules les informations requises s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                            $("#loader-sub-menu").html('<div class="alert aDanger text-white">Alerte: Probl&eacute;me de connexion au corebanking, survenu lors de la recup&eacute;ration de la balance du compte du client. Veuillez refaire l\'op&eacute;ration s\'il vous pla&icirc;t.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        $("#enregistrer").prop('disabled', false);
                },
                error:function(error)
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">La requête a pris beaucoup de temps, veuillez réessayer.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
            });
        }
    }


    function submiter(data)
    {
            $("#loader-sub-menu").val('<img  align="middle" style="height:30px;margin-left:-26px;" src="<?php echo base_url('ikwook_files/images/loadbar.gif')?>" />');
            var url = '<?php echo base_url($module.'/taxdgrk/save/comptant'); ?><?php echo (isset($encaissement->Id_0) && $encaissement->Id_0 != "")?"/".$encaissement->Id_0:""; ?>';
            var gid = '<?php echo $encaissement->Id_0; ?>';
            scrollUP();
            $.ajax({
                    type        : 'POST',
                    url         : url,
                    data        : data,
                    dataType    : 'html',
                    encode          : true,
                    success: function(result){
                            $('#loader-sub-menu').html('');
                            if(result === "E162")
                            {
                                    $("#message").html('');
                                    $('#loader-sub-menu').html('<div class="alert alert-danger"> L\'un des comptes b&eacute;n&eacute;ficiaire de ce paiement n\'existe pas, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "E463")
                            {
                                    $("#message").html('');
                                    $('#loader-sub-menu').html('<div class="alert alert-danger"> La transaction n\'est pas &eacute;quilibr&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "E411")
                            {
                                    $("#message").html('');
                                    $('#loader-sub-menu').html('<div class="alert alert-danger"> Un probl&egrave;me de connexion est survenu, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "E3238")
                            {
                                    $("#message").html('');
                                    $('#loader-sub-menu').html('<div class="alert alert-danger"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "W0205")
                            {
                                    $("#message").html('');
                                    $('#loader-sub-menu').html('<div class="alert alert-danger"> Solde du compte insuffisant !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "E397")
                            {
                                    $("#message").html('');
                                    $('#loader-sub-menu').html('<div class="alert alert-danger"> L\'un des comptes intervenant dans ce paiement pose probl&egrave;me, veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "AD3")
                            {
                                    $("#message").html('');
                                    $('#loader-sub-menu').html('<div class="alert alert-danger"> Le compte du client est gel&eacute;, veuillez contacter le gestionnaire du compte s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "E9999")
                            {
                                    $("#message").html('');
                                    $('#loader-sub-menu').html('<div class="alert alert-danger"> Probl&egrave;me de connexion &agrave; finacle, veuillez refaire la validation s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "ERR002")
                            {
                                    $("#message").html('');
                                    $('#loader-sub-menu').html('<div class="alert alert-danger"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "ERR003")
                            {
                                    $("#message").html('');
                                    $('#loader-sub-menu').html('<div class="alert alert-danger"> Compte invalide , veuillez v&eacute;rifier les comptes s\'il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else if(result === "P83")
                            {
                                    $("#message").html('');
                                    $('#loader-sub-menu').html('<div class="alert alert-danger"> Le paiement avec des devises diff&eacute;rentes n\'est encore pas autoris&eacute; !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                            }
                            else
                            {
                                    $('#step2').remove;
                                    $("#step-2").removeClass('bg-green-active');
                                    $("#step-2").addClass('bg-gray');
                                    $("#step-3").removeClass('bg-gray');
                                    $("#step-3").addClass('bg-green-active');

                                    var url = '<?php echo base_url($module.'/taxdgrk/display/preview'); ?>/' + result;
                                    $.get(url, function(data, status){
                                        $('#loader-sub-menu').html('<div class="alert alert-success">Bravo! paiement encaiss&eacute; avec succ&egrave;s !.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                                        $("#pager").html(data);
                                    });
                            }
                    },
                    error:function(error)
                    {
                        $('#loader-sub-menu').html('<div class="alert alert-warning">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }
            });
    }

    function scrollUP(){
        $('html, body').animate({
            scrollTop: $("#loader-sub-menu").offset().top
        }, 20);
    }

</script>