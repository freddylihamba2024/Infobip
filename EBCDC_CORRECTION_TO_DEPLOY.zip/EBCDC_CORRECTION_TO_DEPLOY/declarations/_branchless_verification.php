<?php $userid = $encaissement->Makerid_9; $feuille=''; $infos = json_decode($encaissement->Notereference_30, true); $disabled = "disabled"; ?>


<?php //if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0) {$feuille='view'; $title ="D&eacute;tails de l'encaissement"; }else{ $feuille=''; $title ="Nouvel encaissement"; $disabled = "";}?>
<?php if($encaissement->Montant_11 > 0) $encaissement->Montant_11 = number_format($encaissement->Montant_11,2,","," "); ?>
<?php if($encaissement->Notemontant_28 > 0) $encaissement->Notemontant_28 = number_format($encaissement->Notemontant_28,2,","," "); ?>
<?php if($_SESSION['Logiref_role']==4 && $userid==$this->session->userdata("user_id") && $encaissement->Status_2==1 && $encaissement->Checkerid_10==0) $feuille='';?>
<?php //$Standard01='';?>
 

<?php if(isset($_POST['Reference_14']) && $_POST['Reference_14'] !='') {$reference = $_POST['Reference_14'];}elseif(isset($content['Reference_32']) && $content['Reference_32'] !=""){$reference = $content['Reference_32'];}else{ $reference = "";}?> 
<?php if(isset($_POST['Nif_17']) && $_POST['Nif_17'] !='') {$nif = $_POST['Nif_17'];}elseif (isset($content['Nif']) && $content['Nif'] !=""){$nif = $content['Nif'];}else{ $nif = "";}?>
<?php if(isset($client->Designation_5) && $client->Designation_5 !='') {$designation = $client->Designation_5;}elseif (isset($content['Denomination']) && $content['Denomination'] !=""){$designation = $content['Denomination'];}else{ $designation = "";}?>
<?php
if(isset($_SESSION['Bank_rates'])):
    $taux = json_decode($_SESSION['Bank_rates'], true);
else: 
    $taux['Dollar_4']  = 00;
    $taux['Euro_5']  = 00;
    $taux['Rand_6']  = 00;
endif;
if(!isset($infos['totalMontant']))
{
        $infos['totalMontant'] = '';
        $infos['totalDevise'] = $encaissement->Devise_12;
}
?>


<?php echo form_open('', array('id' => 'form', 'class' => '')); ?>
    <style>label {min-width: 150px !important;}</style>
    <?php $chtml->box_body_opening('', true);?>
    <input type="hidden" name="Id_0" value="<?php echo $encaissement->Id_0; ?>" />
    <input type="hidden" name="Account_3" value="<?php echo $encaissement->Account_3; ?>" />
    <input type="hidden" name="Logirefid_4" value="<?php echo $encaissement->Logirefid_4; ?>" />
    <input type="hidden" name="Agence_20" value="<?php echo $encaissement->Agence_20; ?>" />
    <input type="hidden" name="Guichet_21" value="<?php echo $encaissement->Guichet_21; ?>" id="guichetId" />
    <input type="hidden" name="Sydonia_44" value="<?php echo $encaissement->Sydonia_44; ?>" />
    <input type="hidden" name="Tresor_45" value="<?php echo $encaissement->Tresor_45; ?>" />
    <input type="hidden" name="Retected" id="retected" value="" />

    <?php $chtml->box_body_opening('', true);?>

    <div class="box-body">
        <div class="row">
            <div class="col-md-12">
                <h2 class=" f20 w-300 page-header">Veuillez renseigner toutes les informations requises</h2>
                <div id="loader"></div>
            </div>
        </div>
 
        <!------------------------- Beneficiare  ------------------------------>
        <div class="row">
            <div class="col-md-12"><br/><label>Partie 1 : R&eacute;gies financi&egrave;re</label><br/></div>
        </div>
        <div class="row">
            <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Beneficaire_15">B&eacute;n&eacute;ficiare</label> 
                        </span>
                        <?php echo form_dropdown('Beneficaire_15', array('DGI'), 'DGI', ' class="form-control bg-gray" required="required"  '); ?>
                        <?php if($encaissement->Id_0 !=NULL): ?>
                            <input type="hidden" name="Beneficaire_15" value="<?php echo $encaissement->Beneficaire_15; ?>" />
                        <?php endif; ?>
                    </div>
            </div> 
            <div class="col-md-7">
                    <div class="input-group"  id="regie0">
                        <span class="input-group-addon">
                            <label for="Service_16"><div id="ServiceId">Service recouvrement</div></label> 
                        </span>
                        <span id="slist"><?php echo form_dropdown('Service_16', $services, $encaissement->Service_16, 'class="form-control chosen-select" id="service" required="required" '); ?></span>
                        <?php if($encaissement->Id_0 !=NULL): ?>
                            <input type="hidden" name="Service_16" value="<?php echo $encaissement->Service_16; ?>" />
                        <?php endif; ?>
                    </div>
            </div> 
        </div>
        
        <!-------------------------  Titre de perception  ------------------------------>
        <div class="row">
            <div class="col-md-12"><br/><label>Partie 2 : Titre de paiement</label><br/></div>
        </div>
        <div class="row">
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Noteid_26"><div id="TitreId">Num&eacute;ro</div></label> 
                    </span>
                    <?php echo form_input('Noteid_26', set_value('Noteid_26', $encaissement->Noteid_26), ' class="form-control" id="reftitre" maxlength="25"'); ?>
                </div>
            </div>
            <div class="col-md-7">
               <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notetype_25">Document</label> 
                    </span>
                   <?php echo form_dropdown('Notetype_25', $documents, $encaissement->Notetype_25, 'class="form-control" disabled="disabled" id="doc" required="required" '); ?>
                    <input type="hidden" name="Notetype_25" value="1">
                </div>
            </div>
        </div>
        <div class="row">
            <div id="bl" class="col-md-12"></div>
        </div>
        <div class="row">
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notedate_27">Date &eacute;mission</label>
                    </span>
                    <?php echo form_input('Notedate_27', set_value('Notedate_27', date('Y-m-d', strtotime($encaissement->Notedate_27))), ' id="datepicker1" class="form-control" maxlength="10"  required="required" '); ?>
                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                </div>
            </div>
            <div class="col-md-7">
                 <div class="input-group"  id="recette0">
                    <span class="input-group-addon">
                        <label for="Typerecette_17">Nature paiement</label> 
                    </span>
                    <span id="rlist"><?php echo form_dropdown('Typerecette_17', $recettes, $encaissement->Typerecette_17, 'class="form-control" id="recette" required="required" '); ?></span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Infos[NumeroTitre]">Num&eacute;ro de titre</label> 
                    </span>
                    <?php echo form_input("Infos[NumeroTitre]", set_value("Infos[NumeroTitre]", (isset($infos['NumeroTitre']))? $infos['NumeroTitre'] : ''), ' class="form-control" id=""  maxlength="45"'); ?>
                </div>
            </div>
            <div class="col-md-7">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Infos[Motif]">Motif de paiement</label> 
                    </span>
                    <?php echo form_input("Infos[Motif]", set_value("Infos[Motif]",(isset($infos['Motif']))? $infos['Motif'] : '') , ' id="" class="form-control" maxlength="45" '); ?>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="standard">Ech&eacute;ance</label> 
                    </span>
                    <?php echo form_input("Infos[standard]", set_value("Infos[standard]", $infos['standard']), ' class="form-control" id="datepicker3" maxlength="25"'); ?>
                </div>
            </div>
            <div class="col-md-5">
                <div class="input-group">
                    <span class="input-group-addon">
                        <label for="Notemontant_28">Montant de la note</label> 
                    </span>
                    <?php echo form_input('Notemontant_28', set_value('total', $encaissement->Notemontant_28), ' id="montantNote" class="form-control" required="required"'); ?>
                </div>
            </div>
            <div class="col-md-2">
                <div class="input-group">
                    <span class="input-group-addon" style="padding-left:0px !important"></span>
                    <?php echo form_dropdown('Notedevise_29', $devises, $encaissement->Notedevise_29, 'class="form-control" id="deviseNote"  required="required"'); ?>
                </div>
            </div>
        </div>
        
        <!------------------------- Payement  ------------------------------>
        <div class="row">
            <div class="col-md-5 border"><br/><label>Partie 3 : Client, Assujetti ou Contribuable </label><span id="info" class="text-red" style="padding-left:90px; "></span></div>
            <div class="col-md-7 border" id="accountinfo"><span id="info" class="text-red" style="padding-left:0px; "></span><br/><label id="acccountname" style="">Intitul&eacute; du compte :&nbsp;&nbsp;<span style="color : green !important" id="accountname"><?php echo(isset($infos['accountname']))? $infos['accountname']:''; ?></span></label></div>
        </div>
        <div class="row">
            <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Nif_13">Num&edot;ro imp&ocirc;t</label> 
                        </span>
                        <?php echo form_input('Nif_13', set_value('Nif_13', $encaissement->Nif_13), 'class="form-control" required="required" maxlength="86"'); ?>
                    </div>
            </div> 
            <div class="col-md-7">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Designation_14">D&eacute;signation</label> 
                        </span>
                        <?php echo form_input('Designation_14', set_value('Designation_14', $encaissement->Designation_14), 'class="form-control" required="required" maxlength="86"'); ?>
                    </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-5">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Mode_19">Mode de paiement</label> 
                        </span>
                        <?php echo form_dropdown('Mode_19', $modes, $encaissement->Mode_19, 'class="form-control" required="required" id="modeId"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Taux_41">Taux de change</label> 
                        </span>
                        <?php echo form_input('Taux_41', ($encaissement->Taux_41 !="") ? $encaissement->Taux_41 : $taux['Dollar_4'], 'class="form-control" id="Taux"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                           <label for="Datevaleur_31">Date paiement</label>
                        </span>
                        <?php echo form_input('Datevaleur_31', set_value('Datevaleur_31', date('Y-m-d', strtotime($encaissement->Datevaleur_31))), ' id="datepicker2" class="form-control" maxlength="10"  required="required" '); ?>
                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Reference_32">R&eacute;f&eacute;rence de l&apos;OP</label>
                        </span>
                        <?php echo form_input('Reference_32', set_value('Reference_32', $encaissement->Reference_32), 'class="form-control"'); ?>
                    </div>
            </div> 
            <div class="col-md-5">
                    <div class="input-group"> 
                        <span class="input-group-addon">
                            <label for="Compte_33"><div id="compteLabel">Compte du client</div></label> 
                        </span>
                        <?php echo form_input('Compte_33', set_value('Compte_33', $encaissement->Compte_33 ), 'class="form-control" placeholder="Compte bancaire du client" required="required" id="compteId" maxlength="26"'); ?>
                        <input type="hidden" name="Infos[accountname]" value="<?php echo(isset($infos['accountname']))? $infos['accountname']:''; ?>" id="account_name">
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Montant_11">Montant &agrave; payer</label> 
                        </span>
                        <?php echo form_input('Montant_11', set_value('Montant_11', $encaissement->Montant_11), 'class="form-control" id="recetteMontant" required="required"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Commission_23"><div id="commiision">Commission</div></label>
                        </span>
                        <?php echo form_input('Commission_23', set_value('Commission_23', $encaissement->Commission_23), 'class="form-control" id="commission"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="Total">Montant total</label> 
                        </span>
                        <?php echo form_input("Infos[totalMontant]", set_value('Total', $infos['totalMontant']), 'class="form-control bg-gray" id="montantTotal"'); ?>
                    </div>
            </div>
            <div class="col-md-2">
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_34', $devises, $encaissement->Devise_34, 'class="form-control"  required="required" id="compteDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_12', $devises, $encaissement->Devise_12, 'class="form-control"  required="required" id="recetteDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown('Devise_24', $devises, $encaissement->Devise_24, 'class="form-control"  required="required" id="commissionDevise"'); ?>
                    </div>
                    <div class="input-group">
                        <span class="input-group-addon" style="padding-left:0px !important"></span>
                        <?php echo form_dropdown("Infos[totalDevise]", $devises, $infos['totalDevise'], 'class="form-control bg-gray"  required="required" id="totalDevise"'); ?>
                    </div>
            </div>
        </div>
        
        <!-------------------------  DGI Cotisation  ------------------------------>
        <div id="DGICotisation" style="<?php echo ($encaissement->Typerecette_17 == "IPRIER") ? '' : 'display: none;'; ?>">
            <div class="row">
                <div class="col-md-12"><br/><label>Partie 3 : Informations additionnelle</label><br/></div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="RefONEM">R&eacute;f&eacute;rence ONEM</label> 
                        </span>
                        <?php echo form_input("Infos[RefONEM]", set_value("Infos[RefONEM]", $infos['RefONEM']), 'class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="RefINPP">R&eacute;f&eacute;rence INPP</label> 
                        </span>
                        <?php echo form_input("Infos[RefINPP]", set_value("Infos[RefINPP]", $infos['RefINPP']), 'class="form-control"'); ?>
                    </div>
                </div> 
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="RefINSS">R&eacute;f&eacute;rence CNSS</label> 
                        </span>
                        <?php echo form_input("Infos[RefINSS]", set_value("Infos[RefINSS]", $infos['RefINSS']), 'class="form-control"'); ?>
                    </div>
                </div> 
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="QuotasONEM">Quatas ONEM</label> 
                        </span>
                        <?php echo form_input("Infos[QuotasONEM]", set_value("Infos[QuotasONEM]", $infos['QuotasONEM']), 'class="form-control"'); ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="QuotasINPP">Quotas INPP</label> 
                        </span>
                        <?php echo form_input("Infos[QuotasINPP]", set_value("Infos[QuotasINPP]", $infos['QuotasINPP']), 'class="form-control"'); ?>
                    </div>
                </div> 
                <div class="col-md-4">
                    <div class="input-group">
                        <span class="input-group-addon">
                            <label for="QuotasINSS">Quotas CNSS</label> 
                        </span>
                        <?php echo form_input("Infos[QuotasINSS]", set_value("Infos[QuotasINSS]", $infos['QuotasINSS']), 'class="form-control"'); ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!------------------------- Repartitions  ------------------------------>
        <div class="row">
            <div class="col-md-12 border"><br/><label>Sch&eacute;ma de comptabilisation </label><span id="info" class="text-red" style="padding-left:180px; "></span></div>
        </div>
        <div class="row">
            <div  id="Comptabilisation" class="col-md-12">

            </div>
        </div>
        <!-------------------------  END  ------------------------------>
    </div>

    <div  class="box-footer clearfix">
        <div class="row">
            <div id="createPaiement" class="col-md-12">
                <!-------------------------  No valider  ------------------------------> 
                <?php if($encaissement->Checkerid_10 ==0 && ($userid == $this->session->userdata("user_id") || $_SESSION['Logiref_role']!=4)): ?>
                    <?php if($_SESSION['Logiref_role']!=5): ?>
                        <button type="button" id='enregistrer' class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;Valider&nbsp;&nbsp;</button>&nbsp;&nbsp;
                        <button type="button" id="delete" class="btn btn-danger"><i class="fa fa-print"></i>&nbsp;&nbsp;Rejeter ce paiement&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <?php endif; ?>
                    <button type="button" id="print" disabled="" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <?php endif; ?>

                <!-------------------------  Valider  ------------------------------> 
                <?php if($encaissement->Checkerid_10 > 0 && ($userid == $this->session->userdata("user_id") || $_SESSION['Logiref_role']!=4)): ?>
                    <button type="submit" disabled="" class="btn btn-success pull-left"><i class="fa fa-save"></i>&nbsp;&nbsp;<?php if($_SESSION['Logiref_role']==3 || $_SESSION['Logiref_role']==2) echo "Valider"; else echo "Modifier"; ?>&nbsp;&nbsp;</button>&nbsp;&nbsp;
                    <button type="button" disabled="" id="delete" class="btn btn-danger"><i class="fa fa-upload"></i>&nbsp;&nbsp;Supprimer ce paiement&nbsp;</button>&nbsp;&nbsp;
                <?php endif; ?>

                <?php if($encaissement->Checkerid_10 > 0):?>
                    <button type="button" id="print" class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer l'attestation&nbsp;&nbsp;</button>&nbsp;&nbsp;
                <?php endif; ?>

                <button type="button" id="schema"  class="btn btn-primary"><i class="fa fa-print"></i>&nbsp;&nbsp;Imprimer le sch&eacute;ma comptable &nbsp;&nbsp;</button>&nbsp;&nbsp;
                <a id="closePanel" type="button" class="btn btn-warning"><i class="fa fa-times white"></i>&nbsp;&nbsp;Quitter&nbsp;&nbsp;</a>&nbsp;&nbsp;
            </div>
        </div>
    </div>
<?php $chtml->box_body_closing(); ?>

<?php echo form_close(); ?>
<div class="modal fade" id="modal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 id='title' class="modal-title">Rejet de paiement</h4>
            </div>
            <div id="modal-pager" class="modal-body">
                <p>One fine body&hellip;</p>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
      <!-- /.modal-dialog -->
</div>  
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/chosen/chosen.jquery.js'); ?>" type="text/javascript"></script>    
<script src="<?php echo base_url('ikwook_bootstraps/v1/js/bootstrap-datepicker.js'); ?>" type="text/javascript"></script>
<script src="<?php echo base_url('ikwook_bootstraps/v4/js/plugins/sweetalert/sweetalert.min.js'); ?>" type="text/javascript"></script>

<!-------------------------  Section identique a Step 2  ------------------------------>
<script type="text/javascript"  charset="utf-8">
var ref = '<?php echo $encaissement->Id_0;?>'; 

var controller ='<?php echo $controller;?>';
var from = '<?php echo $from;?>';

var montant_total = '';

$("#contenter").on("click", "#close_form", function(){
        
        close_form();
});

$('.chosen-select').chosen({width: "100%"});

//Datepicker
$('#datepicker1').datepicker({
        todayHighlight: true,
        format: 'yyyy-mm-dd'
});
$('#datepicker2').datepicker({
        todayHighlight: true,
	format: 'yyyy-mm-dd'
});
$('#datepicker3').datepicker({
        todayHighlight: true,
	format: 'mm-yyyy'
});

$('#montantNote').change(function(){
        var note = $('#montantNote').val();
        $('#recetteMontant').val(note);
        commission();
});

$('#deviseNote').change(function(){
        var devise = $('#deviseNote option:selected').val();
        $('#recetteDevise').val(devise);
        $('#totalDevise').val(devise);
        commission();
});

$('#recetteMontant').change(function(){
        var montant = $('#recetteMontant').val();
        var note = $('#montantNote').val();
        var deviseNote = $('#deviseNote option:selected').val();
        var recetteDevise = $('#recetteDevise option:selected').val();
        
        if((recetteDevise === deviseNote) && (montant > note))
        {
                $('#info').html('Attention! Le montant pay&eacute; ne peut pas &ecirc;tre sup&eacute;rieur au montant de la note!');
        }
        else
        {
                var commissions = parseFloat($("#commission").val());
        
                if(commissions !='0' && commissions !='')
                {
                        montant = parseFloat(montant);
                        montant = commissions + montant;
                        $('#montantTotal').val(montant);
                }
                
                $('#info').html('');
                commission();
        }  
});

$('#recetteDevise').change(function(){
        commission();
});

$('#service').change(function(){
        commission();
});

$('#commission').change(function(){
        var commissions = $("#commission").val();
        if(commissions !='0' && commissions !='')
        {
                commissions = parseFloat($("#commission").val());
                if(montant_total !='0' && montant_total !='')
                {
                    montant_total = parseFloat($('#montantTotal').val());

                    montant_total += commissions;

                    $('#montantTotal').val(montant_total);
                }
                else
                {
                    var montant = $('#recetteMontant').val();
                    montant = parseFloat(montant);
                    montant += commissions;
                    $('#montantTotal').val(montant);
                }
        }
        else if(commissions=='0' || commissions=='')
        {
                var montant = $('#recetteMontant').val();
                $('#montantTotal').val(montant);
        }
});


$("#pager").on("change", "#recette", function(){
        commission();

        var recette = $('#recette option:selected').val();
        if(recette === 'IPRIER'){
            $("#DGICotisation").css('display', '');
        }
        else
        {
            $("#DGICotisation").css('display', 'none');
        }
});


$("#enregistrer").click(function(event){
    
        event.preventDefault();
        $("#loader").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        scrollUP(); 
        var message = '<div class="alert alert-success text-white">Bravo! validation  effectu&eacute;e avec succes!.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>';
        var url = '<?php echo base_url($module.'/declaration/save/rbo_verified'); ?>/';
        var data = $("#form").serialize();
        $(this).prop('disabled', true);
        $.ajax({
                type        : 'POST', 
                url         : url, 
                data        : data, 
                dataType    : 'html', 
                encode          : true,
                success: function(result){
                        $('#loader').html('');
                        if(result === "E300")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white">L\'envoi des &eacute;critures &agrave; amplitude fait avec succ&egrave;s, sauf que les &eacute;critures ne sont pas int&eacute;gr&eacute;es ou sont int&eacute;gr&eacutes partiellement d&ucirc; &agrave; un probl&eacute;me du d&eacute;saccord commercial ou administratif ou du chapitre d\'un compte. Allez dans le menu regularisation pour regulariser ce paiement. <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E404")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white">L\'envoi des &eacute;critures &agrave; amplitude fait avec succ&egrave;s, sauf que les &eacute;critures ne sont pas int&eacute;gr&eacute;es ou sont int&eacute;gr&eacutes partiellement d&ucirc; au probl&eacute;me de compte fermé, chapitre non autorisé ou sens du compte incorrect. Allez dans le menu regularisation pour regulariser ce paiement!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E411")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> L\'envoi des &eacute;critures &agrave; amplitude fait avec succ&egrave;s. Mais amplitude a retourn&eacute; une r&eacute;ponse partielle par rapport au lot des &eacute;critures envoy&eacute;es. Allez dans le menu regularisation pour regulariser ce paiement !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E405")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-warning text-white">Aucune &eacute;criture envoy&eacute;e &agrave; amplitude pour ce paiement d&ucirc; au probl&egrave;me d\'informations manquantes.<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else if(result === "E412")
                        {
                                $("#message").html('');
                                $('#loader').html('<div class="alert alert-danger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse amplitude est d&eacute;pass&eacute;. Allez dans le menu regularisation pour regulariser ce paiement !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }
                        else
                        {
                                $('#loader').html(message);
                        }
                },
                error:function(error)
                {
                    $('#loader').html('<div class="alert alert-danger text-white"> Le d&eacute;lai d\'attente de r&eacute;ponse amplitude est d&eacute;pass&eacute;. Ce paiement peut se trouver dans le menu reversement isys si ç\'a &eacute;t&eacute; valid&eacute; ou dans le menu regularisation de paiement si ça n\'a pas &eacute;t&eacute; compl&egrave;ment int&eacute;gr&eacute; dans amplitude !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
        });    
    
});


$("#delete").click(function(event){
        $(this).prop('disabled', true);
        event.preventDefault();
        var url = '<?php echo base_url($module.'/declaration/display/motif'); ?>/';
        $(this).prop('disabled', true);
        $.get(url, function(data, status){
            $("#loader1").html('');
            $('#modal').modal('show'); 
            $("#modal-pager").html(data);
        }); 
});


$("#compteId").change(function(){
    get_accountname(); 
});

$("#compteDevise").change(function(){
    get_accountname(); 
});

$("#cancel").click(function(){
        location.reload(true);
});

function commission(){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        $("#commission").val('');
        $("#Devise_24").prop("selectedIndex", 0);
        var mode = $('#modeId').val();
        var montant = $('#recetteMontant').val();
        var regie = 'DGI';
        var commission = $("#commission").val();
        var service = $('#service option:selected').val();
        var devise = $('#recetteDevise option:selected').val();
        var recette = $('#recette option:selected').val();
        var guichet = $('#guichetId').val();
        var taux = $('#Taux').val();
        
        if(montant !== '' && devise !== '' && service !== ''){
            var url = '<?php echo base_url($module.'/fees/display/default'); ?>/<?php echo $encaissement->Id_0; ?>';
            $.ajax({
                    type        : 'POST', 
                    url         : url, 
                    data        : { mode : mode, regie : regie, service : service, recette : recette ,devise: devise, montant:montant, guichet: guichet }, 
                    dataType    : 'html', 
                    encode          : true,
                    success: function(reponse)
                    {
                        var result = JSON.parse(reponse);
                        
                        if(commission == '' || commission == '0')
                        {
                            $("#commission").val(result[0]);
                            $("#commissionDevise").val(result[1]);
                            $("#montantTotal").val(result[2]);
                        }
                        
                    },
                    error:function(error)
                    {
                        $('#bl').html('');
                        $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    }  
            });    
        }
}


$("#closePanel").click(function(){
   
    closeView(controller,from);
    
});

function closeView(controller, display)
{
        if(controller != '' && display != '')
        {
                $.get("<?php echo base_url($module.'/'.$controller.'/display/'.$from); ?>", function(data, status){
                    $("#loader").html('');
                    $("#container").html(data);
                });
        }
        else
        {
                <?php if($_SESSION['Logiref_role'] == 4){ ?>
                        
                        close_form();
                        
                <?php }else{ ?>
                
                    location.reload(); 
                    
                <?php } ?>
        }
}

function close_form()
{
        $.get("<?php echo base_url($module.'/reports/display/'.$previous_menu); ?>", function (data, status) {
            $("#loader").html('');
            $("#pager").html(data);
            $("#pager").addClass('content');

            $("#close").removeClass('hidden');
            $("#close_form").addClass('hidden');

        });
}

function scrollUP(){
    $('html, body').animate({
        scrollTop: $("#loader").offset().top
    }, 20);
}
</script>

<!-------------------------  Section propres a Step 3  ------------------------------>
<script type="text/javascript"  charset="utf-8">
$("#print").click(function(){

        $('#enregistrer').prop("disabled",true);
        var id = ref;
        var url = '<?php echo base_url($module.'/impression/display/attestation'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});

$("#schema").click(function(){

        var id = ref;
        var url = '<?php echo base_url($module.'/impression/display/schema'); ?>/' + ref;
        //MM_openBrWindow(url,'','addressbar=no,scrollbars=yes,width=900,height=500');
        // window.print();
        var w = window.open(url);

        $(w).ready(function(){
            w.print();
        });
});



<?php if(isset($encaissement->Id_0) && $encaissement->Id_0!='' && $encaissement->Id_0!=0){?>
        var mode = $('#modeId').val();
        if(mode === '7' || mode == '8')
        {
               $("#compteId").prop('disabled',''); 
               $("#compteDevise").prop('disabled',''); 
        }
        comptabilisation('<?php echo $encaissement->Logirefid_4; ?>');
<?php } ?>

function comptabilisation(ref){
        $("#loader").val('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
        var url = '<?php echo base_url($module.'/comptabilisation/display/get_details_dgi'); ?>/' + ref;
        $.get(url, function(data, status){
            $("#Comptabilisation").html(data);
        });
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}

function get_accountname()
{
        var compte = $('#compteId').val();
        var devise = $('#compteDevise option:selected').val();
        var url = '<?php echo base_url($module.'/accounts/data/get_accountname'); ?>';
        if(compte !== '' && devise !=='')
        {   
                $("#accountname").html('<img  align="middle" height="15px" src="<?php echo base_url('ikwook_bootstraps/v0/img/loadbar.gif')?>" />');
                $.ajax({
                        type        : 'POST', 
                        url         : url, 
                        data        : { compte : compte, devise : devise}, 
                        dataType    : 'html', 
                        encode          : true,
                        success: function(reponse)
                        {
                                if(reponse == '404')
                                {
                                        $("#accountname").css('color', 'red');
                                        $("#accountname").html('Ce compte n&apos;existe pas');
                                }
                                else if(reponse == '406')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Probl&egrave;me de connexion &agrave; amplitude!');
                                }
                                else if(reponse == '405')
                                {
                                        $("#accountname").css('color', 'orange');
                                        $("#accountname").html('Le format de compte n\'est pas valide');
                                }
                                else
                                {
                                        $("#accountname").css('color', 'green');
                                        $("#accountname").html(reponse);
                                        $("#account_name").val(reponse);
                                }
                          
                        },
                        error:function(error)
                        {
                            $('#loader').html('<div class="alert alert-warning text-white">ERREUR : Pas de connexion...<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                        }  
                });  
        }
        else
        {
                $("#accountname").html('');
        } 
}
</script>



