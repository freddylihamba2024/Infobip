<div class="row">
    <div class="col-md-12 P-0">
        <div class="row">
            <div class="col-md-1">
                <div id="step-1" title="" class="bRound <?php if($step==1) echo "bg-green-active"; else echo "bg-gray"; ?> f16  center pull-right">1</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">V&eacute;rification de la déclaration<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-2" title="" class="bRound <?php if($step==2) echo "bg-green-active"; else echo "bg-gray"; ?> f16 center pull-right">2</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Confirmation du paiement<br/></div>
            </div>
            <div class="col-md-1">
                <div id="step-3" title="" class="bRound <?php if($step==3) echo "bg-green-active"; else echo "bg-gray"; ?> f16 center pull-right">3</div>
            </div>
            <div class="col-md-3">
                <div class="pull-left">Impression de la preuve<br/></div>
            </div>
        </div>
        <div class="row"><div class="col-md-12"><br/></div></div>
        <div class="row">
            <div id="pager" class="col-md-12">
                <?php if($step==2): ?>
                    <?php echo $this->load->view('_step_2'); ?>
                <?php elseif($step==3): ?> 
                    <?php echo $this->load->view('_step_3'); ?>
                <?php else:?>
                    <?php $chtml->box_body_opening("", true);?>
                    <?php echo form_open('', array('id' => 'mainform', 'class' => '')); ?>
                    <div class="row">
                        <div class="col-md-4">
                            <div id="approvalWarning"></div><br/>
                            <p class="f12 text-black">
                                Renseignez le num&eacute;ro de la d&eacute;claration en suite cliquez sur suivant pour effectuer le paiement de cette d&eacute;claration.
                            </p>
                            <br/><br/>
                        </div>
                        <div class="col-md-8 bLeft">
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="Reference_14" class="f12 text-black">Num&eacute;ro de la d&eacute;claration</label>
                                            <?php echo form_input('Reference_14','', 'class="form-control"  id="Reference_14" '); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="box-footer  clearfix">
                                <div class="row">
                                    <div class="col-md-12">
                                        <button type="submit" style="margin-left:5px;" name="submit" class="btn btn-primary margin"><i class="fa fa-search"></i> Suivant -> </button>&nbsp;
                                        <button id="saisie" type="button" style="margin-left:5px;" name="button" class="btn btn btn-default pull-left margin" disabled='disabled'><i class="fa fa-pencil"></i> Saisie manuelle </button>
                                        <a class="btn btn-warning" href="">&nbsp; Quitter &nbsp;</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo form_close(); ?>
                    <?php $chtml->box_body_closing(); ?>

                <?php endif;?>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    
    $('#mainform').submit(function(event) {
        // stop the form from submitting the normal way and refreshing the page
        event.preventDefault();
        var data = $(this).serialize();
        next_step(data);
   
    });

    function next_step(data) {  
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . '/taxdeclaration/display/verification'); ?>';
        
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(result) {
                $("#loader-sub-menu").html('');
                if(result === "E404")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">D&eacute;sol&eacute;... Aucune information trouv&eacute;e pour la r&eacute;f&eacute;rence saisie !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#saisie").removeClass('btn-default');
                    $("#saisie").addClass('btn-success');
                    $("#saisie").prop("disabled", '');
                }
                else if(result === "E402")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">D&eacute;sol&eacute; le nif saisi ne correspond pas &agrave; la note, veuillez v&eacute;rifier s\il vous pla&icirc;t !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result === "E302")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">D&eacute;sol&eacute;... Aucune information trouv&eacute;e pour la r&eacute;f&eacute;rence saisie !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#saisie").removeClass('btn-default');
                    $("#saisie").addClass('btn-success');
                    $("#saisie").prop("disabled", '');
                }
                else if(result === "E405")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Un probl&eacute;me est survenu lors de la r&eacute;cup&eacute;ration de la note, veuillez réessayer s\'il vous pla&icirc;t ! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result === "E406")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Probl&eagrave;me de connexion avec DGIREP !<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                    $("#saisie").removeClass('btn-default');
                    $("#saisie").addClass('btn-success');
                    $("#saisie").prop("disabled", '');
                }
                else if(result === "E202")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Une note avec cette référence existe déjà ! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else if(result === "E203")
                {
                    $("#loader-sub-menu").html('<div class="alert aWarning text-white">Une note avec cette référence est déjà payé ! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                }
                else
                {
                    $("#pager").html(result);
                    $("#step-1").removeClass('bg-green-active');
                    $("#step-1").addClass('bg-gray');
                    $("#step-2").removeClass('bg-gray');
                    $("#step-2").addClass('bg-green-active');
                }
            },
            error: function(error) {
                $("#loader-sub-menu").html('<div class="alert aWarning text-white">Un probl&eacute;me est survenu lors de la r&eacute;cup&eacute;ration de la note, veuillez réessayer s\'il vous pla&icirc;t ! <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
                $("#saisie").removeClass('btn-default');
                $("#saisie").addClass('btn-success');
                $("#saisie").prop("disabled", '');
            }
        });
    }

    $("#saisie").click(function() {

        var data = $("#mainform").serialize();
        $("#loader-sub-menu").html('<img  align="middle" height="30px" src="<?php echo base_url('ikwook_files/images/loadbar.gif'); ?>" />');
        var url = '<?php echo base_url($module . ''); ?>/taxdeclaration/display/create';
        
        $.ajax({
            type: 'POST',
            url: url,
            data: data,
            dataType: 'html',
            encode: true,
            success: function(result) {

                $("#loader-sub-menu").html('');
                $("#pager").html(result);
                $("#step-1").removeClass('bg-green-active');
                $("#step-1").addClass('bg-gray');
                $("#step-2").removeClass('bg-gray');
                $("#step-2").addClass('bg-green-active');

            },
            error: function(error) {
                $("#loader-sub-menu").html('<div class="alert aDanger text-white"> La requête a pris beaucoup de temps, veuillez refaire s\'il vous plaît!<button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button></div>');
            }
        });
    });

    $("#cancel").click(function() {
        location.reload(true);
    });
</script>